import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'bookings.json');

app.use(express.json());

// Ensure data directory and file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const SEED_BOOKINGS = [
  {
    id: 'seed-1',
    referenceId: 'LHC-2026-1042',
    patientName: 'Rameshwar Dayal Verma',
    phoneNumber: '9826214589',
    age: 62,
    serviceType: 'Diabetes & Blood Sugar Management',
    preferredDate: new Date().toISOString().split('T')[0],
    preferredTimeSlot: 'Morning: 10:00 AM - 11:30 AM',
    visitType: 'Clinic',
    problemDescription: 'Fasting sugar 210, needs insulin dose review and HbA1c consultation.',
    status: 'Confirmed',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    notes: 'Regular patient from Basant Vihar.',
  },
  {
    id: 'seed-2',
    referenceId: 'LHC-2026-1043',
    patientName: 'Kamla Devi Agrawal',
    phoneNumber: '9425128790',
    age: 74,
    serviceType: 'Day Care IV Drip / Injection Facility',
    preferredDate: new Date().toISOString().split('T')[0],
    preferredTimeSlot: 'Morning: 11:30 AM - 01:00 PM',
    visitType: 'Home Visit',
    problemDescription: 'Severe dehydration and weakness after viral fever. Requires IV NS drip at home in Lashkar.',
    status: 'Pending',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    notes: 'Home visit requested for elderly patient.',
  },
  {
    id: 'seed-3',
    referenceId: 'LHC-2026-1044',
    patientName: 'Vikram Singh Tomar',
    phoneNumber: '9926458912',
    age: 48,
    serviceType: 'Blood Pressure / Hypertension Check',
    preferredDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    preferredTimeSlot: 'Evening: 05:00 PM - 06:30 PM',
    visitType: 'Clinic',
    problemDescription: 'Constant occipital headache, BP recorded 160/100 at chemist.',
    status: 'Confirmed',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    notes: 'First time visit.',
  },
];

if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(SEED_BOOKINGS, null, 2), 'utf-8');
}

function readBookings(): any[] {
  try {
    if (!fs.existsSync(DATA_FILE)) return SEED_BOOKINGS;
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading bookings file:', e);
    return SEED_BOOKINGS;
  }
}

function writeBookings(data: any[]): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error writing bookings file:', e);
  }
}

// REST API Endpoints
app.get('/api/bookings', (_req, res) => {
  const bookings = readBookings();
  res.json(bookings);
});

app.post('/api/bookings', (req, res) => {
  const newBooking = req.body;
  if (!newBooking || !newBooking.patientName || !newBooking.phoneNumber) {
    return res.status(400).json({ error: 'Patient name and phone number are required.' });
  }
  const bookings = readBookings();
  bookings.unshift(newBooking);
  writeBookings(bookings);
  res.status(201).json(newBooking);
});

app.patch('/api/bookings/:id', (req, res) => {
  const { id } = req.params;
  const { status, notes } = req.body;
  const bookings = readBookings();
  const idx = bookings.findIndex((b: any) => b.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Booking not found.' });
  }
  if (status) bookings[idx].status = status;
  if (notes !== undefined) bookings[idx].notes = notes;
  writeBookings(bookings);
  res.json(bookings[idx]);
});

app.delete('/api/bookings/:id', (req, res) => {
  const { id } = req.params;
  const bookings = readBookings();
  const filtered = bookings.filter((b: any) => b.id !== id);
  writeBookings(filtered);
  res.json({ success: true });
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Lahariya Health Clinic server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
