export type Language = 'en' | 'hi';

export type VisitType = 'Clinic' | 'Online Video Consult' | 'Home Visit';

export type BookingStatus = 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';

export interface Booking {
  id: string;
  referenceId: string;
  patientName: string;
  phoneNumber: string;
  age: number;
  serviceType: string;
  preferredDate: string; // YYYY-MM-DD
  preferredTimeSlot: string;
  visitType: VisitType;
  problemDescription?: string;
  status: BookingStatus;
  createdAt: string;
  notes?: string;
}

export interface ServiceItem {
  id: string;
  iconName: string;
  titleEn: string;
  titleHi: string;
  descEn: string;
  descHi: string;
  tagsEn: string[];
  tagsHi: string[];
  highlight?: boolean;
}

export interface ReviewItem {
  id: string;
  patientName: string;
  localityEn: string;
  localityHi: string;
  rating: number;
  date: string;
  commentEn: string;
  commentHi: string;
  treatmentEn: string;
  treatmentHi: string;
  verified: boolean;
}

export interface SpecialProgramItem {
  id: string;
  titleEn: string;
  titleHi: string;
  badgeEn: string;
  badgeHi: string;
  priceEn: string;
  priceHi: string;
  descEn: string;
  descHi: string;
  scheduleEn: string;
  scheduleHi: string;
  featuresEn: string[];
  featuresHi: string[];
  icon: string;
  accentColor: string;
}
