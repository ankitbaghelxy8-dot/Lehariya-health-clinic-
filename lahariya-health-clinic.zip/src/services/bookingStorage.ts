import { Booking, BookingStatus } from '../types';

const STORAGE_KEY = 'lahariya_clinic_bookings_v1';

// Seed initial bookings for demonstration and instant staff testing
const INITIAL_SEED_BOOKINGS: Booking[] = [
  {
    id: 'seed-1',
    referenceId: 'LHC-2026-1042',
    patientName: 'Rameshwar Dayal Verma',
    phoneNumber: '9826214589',
    age: 62,
    serviceType: 'Diabetes & Blood Sugar Management',
    preferredDate: new Date().toISOString().split('T')[0],
    preferredTimeSlot: 'Morning: 10:00 AM - 11:30 AM',
    visitType: 'Clinic',
    problemDescription: 'Fasting sugar 210, needs insulin dose review and HbA1c consultation.',
    status: 'Confirmed',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    notes: 'Regular patient from Basant Vihar.',
  },
  {
    id: 'seed-2',
    referenceId: 'LHC-2026-1043',
    patientName: 'Kamla Devi Agrawal',
    phoneNumber: '9425128790',
    age: 74,
    serviceType: 'Day Care IV Drip / Injection Facility',
    preferredDate: new Date().toISOString().split('T')[0],
    preferredTimeSlot: 'Morning: 11:30 AM - 01:00 PM',
    visitType: 'Home Visit',
    problemDescription: 'Severe dehydration and weakness after viral fever. Requires IV NS drip at home in Lashkar.',
    status: 'Pending',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    notes: 'Home visit requested for elderly patient.',
  },
  {
    id: 'seed-3',
    referenceId: 'LHC-2026-1044',
    patientName: 'Vikram Singh Tomar',
    phoneNumber: '9926458912',
    age: 48,
    serviceType: 'Blood Pressure / Hypertension Check',
    preferredDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    preferredTimeSlot: 'Evening: 05:00 PM - 06:30 PM',
    visitType: 'Clinic',
    problemDescription: 'Constant occipital headache, BP recorded 160/100 at chemist.',
    status: 'Confirmed',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    notes: 'First time visit.',
  },
];

function getLocalBookings(): Booking[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_SEED_BOOKINGS));
      return INITIAL_SEED_BOOKINGS;
    }
    return JSON.parse(raw) as Booking[];
  } catch {
    return INITIAL_SEED_BOOKINGS;
  }
}

function saveLocalBookings(bookings: Booking[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
  } catch (err) {
    console.error('Failed to save bookings locally:', err);
  }
}

export async function fetchAllBookings(): Promise<Booking[]> {
  try {
    // Try server endpoint first
    const response = await fetch('/api/bookings', {
      headers: { 'Accept': 'application/json' },
    });
    if (response.ok) {
      const serverData = await response.json();
      if (Array.isArray(serverData) && serverData.length > 0) {
        saveLocalBookings(serverData);
        return serverData;
      }
    }
  } catch {
    // Fall back gracefully to localStorage
  }
  return getLocalBookings();
}

export async function saveNewBooking(
  input: Omit<Booking, 'id' | 'referenceId' | 'status' | 'createdAt'>
): Promise<Booking> {
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const newBooking: Booking = {
    ...input,
    id: 'book_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    referenceId: `LHC-2026-${randomSuffix}`,
    status: 'Pending',
    createdAt: new Date().toISOString(),
  };

  // Save to local storage first for instant feedback
  const existing = getLocalBookings();
  const updated = [newBooking, ...existing];
  saveLocalBookings(updated);

  // Sync with backend if available
  try {
    await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newBooking),
    });
  } catch {
    // Backend silent sync
  }

  return newBooking;
}

export async function updateBookingStatus(
  id: string,
  newStatus: BookingStatus,
  notes?: string
): Promise<Booking | null> {
  const existing = getLocalBookings();
  const idx = existing.findIndex((b) => b.id === id);
  if (idx === -1) return null;

  existing[idx].status = newStatus;
  if (notes !== undefined) {
    existing[idx].notes = notes;
  }
  saveLocalBookings(existing);

  // Sync with backend
  try {
    await fetch(`/api/bookings/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus, notes }),
    });
  } catch {
    // Silent fallback
  }

  return existing[idx];
}

export async function deleteBooking(id: string): Promise<boolean> {
  const existing = getLocalBookings();
  const filtered = existing.filter((b) => b.id !== id);
  saveLocalBookings(filtered);

  try {
    await fetch(`/api/bookings/${id}`, {
      method: 'DELETE',
    });
  } catch {
    // Silent
  }

  return true;
}

export function generateWhatsAppBookingUrl(booking: Booking): string {
  const message = [
    `🏥 *NEW APPOINTMENT BOOKING*`,
    `*Lahariya Health Clinic - Gwalior*`,
    `━━━━━━━━━━━━━━━━━━━━━`,
    `🆔 *Booking Ref:* ${booking.referenceId}`,
    `👤 *Patient:* ${booking.patientName}`,
    `📞 *Phone:* ${booking.phoneNumber}`,
    `🎂 *Age:* ${booking.age} yrs`,
    `🚗 *Visit Type:* ${booking.visitType}`,
    `🩺 *Service:* ${booking.serviceType}`,
    `📅 *Preferred Date:* ${booking.preferredDate}`,
    `⏰ *Preferred Slot:* ${booking.preferredTimeSlot}`,
    booking.problemDescription ? `📝 *Problem/Symptoms:* ${booking.problemDescription}` : '',
    `━━━━━━━━━━━━━━━━━━━━━`,
    `📍 *Clinic:* A-21, Basant Vihar Colony, Lashkar, Gwalior (Plus Code: 655F+8QP)`,
    `📞 *Emergency / WA:* 777-300-8103`,
    `☎️ *Landline:* 0751-3581457`,
    ``,
    `_Dr. Deepankar Lahariya, please confirm this appointment._`,
  ]
    .filter(Boolean)
    .join('\n');

  return `https://wa.me/917773008103?text=${encodeURIComponent(message)}`;
}

export function generatePatientConfirmationWhatsAppUrl(booking: Booking): string {
  const cleanPhone = booking.phoneNumber.replace(/[^0-9]/g, '');
  const targetPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
  
  const message = [
    `✅ *APPOINTMENT CONFIRMED*`,
    `*Lahariya Health Clinic, Gwalior*`,
    `━━━━━━━━━━━━━━━━━━━━━`,
    `Dear ${booking.patientName},`,
    `Your appointment with *Dr. Deepankar Lahariya* (MD Medicine) has been *CONFIRMED*.`,
    ``,
    `🆔 *Ref ID:* ${booking.referenceId}`,
    `📅 *Date:* ${booking.preferredDate}`,
    `⏰ *Time Slot:* ${booking.preferredTimeSlot}`,
    `🚗 *Visit Mode:* ${booking.visitType}`,
    `🩺 *Service:* ${booking.serviceType}`,
    ``,
    `📍 *Clinic Address:*`,
    `A-21, Basant Vihar Colony, Lashkar, Gwalior`,
    `Plus Code: 655F+8QP`,
    `Google Maps: https://maps.google.com/?q=655F%2B8QP+Gwalior`,
    ``,
    `📞 *Emergency / WhatsApp:* 777-300-8103`,
    `☎️ *Home Care Desk:* 0751-3581457 (9 AM - 9 PM)`,
    ``,
    `_In emergency, call 777-300-8103 immediately._`,
  ].join('\n');

  return `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`;
}

export function exportBookingsToCSV(bookings: Booking[]): void {
  const headers = [
    'Reference ID',
    'Patient Name',
    'Phone Number',
    'Age',
    'Visit Type',
    'Service Required',
    'Appointment Date',
    'Time Slot',
    'Status',
    'Problem Notes',
    'Created At',
  ];

  const rows = bookings.map((b) => [
    `"${b.referenceId}"`,
    `"${b.patientName.replace(/"/g, '""')}"`,
    `"${b.phoneNumber}"`,
    b.age,
    `"${b.visitType}"`,
    `"${b.serviceType.replace(/"/g, '""')}"`,
    `"${b.preferredDate}"`,
    `"${b.preferredTimeSlot.replace(/"/g, '""')}"`,
    `"${b.status}"`,
    `"${(b.problemDescription || '').replace(/"/g, '""')}"`,
    `"${b.createdAt}"`,
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `lahariya_clinic_appointments_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
