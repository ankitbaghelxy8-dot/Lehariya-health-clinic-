import React, { useState, useEffect } from 'react';
import { Language, Booking, VisitType } from './types';
import { Header } from './components/Header';
import { EmergencyBanner } from './components/EmergencyBanner';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { DayCareSection } from './components/DayCareSection';
import { HomeHealthcareSection } from './components/HomeHealthcareSection';
import { SpecialProgramsSection } from './components/SpecialProgramsSection';
import { AyushmanCashlessSection } from './components/AyushmanCashlessSection';
import { AboutDoctorSection } from './components/AboutDoctorSection';
import { ClinicGallery } from './components/ClinicGallery';
import { ReviewsSection } from './components/ReviewsSection';
import { MapAndContactSection } from './components/MapAndContactSection';
import { Footer } from './components/Footer';
import { StickyBottomBar } from './components/StickyBottomBar';
import { BookingModal } from './components/BookingModal';
import { BookingConfirmationModal } from './components/BookingConfirmationModal';
import { AdminPortalModal } from './components/AdminPortalModal';

export default function App() {
  // Bilingual state with localStorage persistence
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('lahariya_clinic_lang');
      return saved === 'hi' ? 'hi' : 'en';
    } catch {
      return 'en';
    }
  });

  const toggleLanguage = () => {
    setLang((prev) => {
      const next = prev === 'en' ? 'hi' : 'en';
      try {
        localStorage.setItem('lahariya_clinic_lang', next);
      } catch {
        // Ignore
      }
      return next;
    });
  };

  // Modal states
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingService, setBookingService] = useState<string | undefined>(undefined);
  const [bookingVisitType, setBookingVisitType] = useState<VisitType>('Clinic');

  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  const [isAdminOpen, setIsAdminOpen] = useState(false);

  const handleOpenBooking = (service?: string, visitType: VisitType = 'Clinic') => {
    setBookingService(service);
    setBookingVisitType(visitType);
    setIsBookingOpen(true);
  };

  const handleBookingSuccess = (booking: Booking) => {
    setConfirmedBooking(booking);
    setIsConfirmationOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-800 font-sans">
      {/* 24x7 Emergency Alert Banner */}
      <EmergencyBanner lang={lang} />

      {/* Main Header with Language Switcher */}
      <Header
        lang={lang}
        onToggleLang={toggleLanguage}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero Section */}
        <Hero
          lang={lang}
          onOpenBooking={() => handleOpenBooking()}
        />

        {/* 2. Services Section (12 items) */}
        <ServicesSection
          lang={lang}
          onSelectServiceForBooking={(serviceName) => handleOpenBooking(serviceName, 'Clinic')}
        />

        {/* 3. Day Care Section (10 AM to 8 PM, injection & drip facility) */}
        <DayCareSection
          lang={lang}
          onBookDayCare={(serviceName, visitType) => handleOpenBooking(serviceName, visitType || 'Clinic')}
        />

        {/* 4. Home Healthcare Section */}
        <HomeHealthcareSection
          lang={lang}
          onBookHomeCare={(serviceName) => handleOpenBooking(serviceName, 'Home Visit')}
        />

        {/* 5. Special Programs Section (Diet Chart, Fibroscan, Birthday Checkup) */}
        <SpecialProgramsSection
          lang={lang}
          onSelectProgram={(programName) => handleOpenBooking(programName, 'Clinic')}
        />

        {/* 6. Cashless & Ayushman Card Section */}
        <AyushmanCashlessSection lang={lang} />

        {/* 7. About Dr. Deepankar Lahariya */}
        <AboutDoctorSection
          lang={lang}
          onOpenBooking={() => handleOpenBooking()}
        />

        {/* 8. Clinic Gallery Tour */}
        <ClinicGallery lang={lang} />

        {/* 9. Reviews Section */}
        <ReviewsSection lang={lang} />

        {/* 10. Google Maps & Contact Details */}
        <MapAndContactSection
          lang={lang}
          onOpenBooking={() => handleOpenBooking()}
        />
      </main>

      {/* Footer */}
      <Footer
        lang={lang}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Mobile Sticky Bottom Action Bar */}
      <StickyBottomBar
        lang={lang}
        onOpenBooking={() => handleOpenBooking()}
      />

      {/* Interactive Booking Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        lang={lang}
        initialService={bookingService}
        initialVisitType={bookingVisitType}
        onBookingSuccess={handleBookingSuccess}
      />

      {/* Booking Confirmation Receipt Modal */}
      <BookingConfirmationModal
        booking={confirmedBooking}
        isOpen={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
        lang={lang}
      />

      {/* Staff Admin Portal Modal */}
      <AdminPortalModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        lang={lang}
      />
    </div>
  );
}
