import React from 'react';
import { MapPin, Navigation, Phone, Clock, MessageCircle, ExternalLink, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface MapAndContactSectionProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const MapAndContactSection: React.FC<MapAndContactSectionProps> = ({
  lang,
  onOpenBooking,
}) => {
  const t = translations[lang];

  const googleMapsDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=655F%2B8QP%2C+Lashkar%2C+Gwalior%2C+Madhya+Pradesh+474007`;
  const googleMapsViewUrl = `https://maps.google.com/?q=655F%2B8QP+Gwalior`;

  return (
    <section id="contact" className="py-16 sm:py-24 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 font-bold text-xs uppercase tracking-wider border border-blue-200 mb-3">
            <MapPin className="w-3.5 h-3.5 text-red-600" />
            {t.mapAndContact.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {t.mapAndContact.title}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            {t.mapAndContact.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Details Card */}
          <div className="lg:col-span-5 space-y-4">
            {/* Address box */}
            <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">
                    {t.mapAndContact.addressTitle}
                  </h3>
                  <p className="text-base font-bold text-slate-900 mt-1">
                    {lang === 'hi' ? clinicData.contact.addressHi : clinicData.contact.addressEn}
                  </p>
                  <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 text-xs font-mono font-bold">
                    <span>Plus Code:</span>
                    <span className="text-blue-700 font-bold">{clinicData.contact.plusCode}</span>
                  </div>
                </div>
              </div>

              {/* Get Directions Button */}
              <div className="pt-2">
                <a
                  href={googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-extrabold text-xs sm:text-sm shadow-md shadow-blue-700/20 transition-all"
                >
                  <Navigation className="w-4 h-4 fill-current" />
                  <span>{t.mapAndContact.getDirections}</span>
                  <ExternalLink className="w-3.5 h-3.5 ml-1" />
                </a>
              </div>
            </div>

            {/* Timings Box */}
            <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">
                    {t.mapAndContact.timingsTitle}
                  </h3>
                  <div className="mt-2 space-y-1.5 text-xs sm:text-sm text-slate-700">
                    <p className="font-semibold text-slate-900">
                      {lang === 'hi' ? clinicData.contact.clinicTimingHi : clinicData.contact.clinicTimingEn}
                    </p>
                    <p className="text-emerald-700 font-bold">
                      {lang === 'hi' ? 'डे केयर आईवी ड्रिप: सुबह 10:00 से रात 8:00' : 'Day Care Drip Facility: 10:00 AM – 8:00 PM'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct Calls Box */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-blue-900 to-indigo-950 text-white shadow-xl space-y-4">
              <div>
                <span className="text-[10px] uppercase font-black tracking-widest text-red-300">
                  {lang === 'hi' ? 'त्वरित फोन सहायता' : 'Direct Helpline'}
                </span>
                <h4 className="text-lg font-black text-white mt-0.5">
                  {lang === 'hi' ? '24x7 इमरजेंसी एवं होम केयर' : '24x7 Emergency & Home Care'}
                </h4>
              </div>

              <div className="space-y-2">
                <a
                  href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
                  className="flex items-center justify-between p-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Phone className="w-4 h-4 text-red-400" />
                    <div>
                      <p className="text-xs text-blue-200 font-semibold">{t.mapAndContact.phoneEmergencyTitle}</p>
                      <p className="text-sm font-black text-white">{clinicData.contact.phoneEmergency}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-red-300">Call Now</span>
                </a>

                <a
                  href={`tel:${clinicData.contact.phoneLandlineRaw}`}
                  className="flex items-center justify-between p-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Phone className="w-4 h-4 text-blue-300" />
                    <div>
                      <p className="text-xs text-blue-200 font-semibold">{t.mapAndContact.phoneLandlineTitle}</p>
                      <p className="text-sm font-black text-white">{clinicData.contact.phoneLandline}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-blue-300">Call Now</span>
                </a>
              </div>

              <div className="pt-1 flex gap-2">
                <a
                  href={`https://wa.me/${clinicData.contact.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>{t.mapAndContact.chatWhatsAppBtn}</span>
                </a>

                <button
                  onClick={onOpenBooking}
                  className="flex-1 py-2.5 rounded-xl bg-white text-blue-900 font-extrabold text-xs hover:bg-blue-50 transition-colors cursor-pointer"
                >
                  {t.nav.bookNow}
                </button>
              </div>
            </div>
          </div>

          {/* Google Maps Embed Container */}
          <div className="lg:col-span-7">
            <div className="rounded-3xl bg-white p-3 sm:p-4 border border-slate-200 shadow-xl overflow-hidden relative">
              <div className="relative w-full h-[400px] sm:h-[480px] rounded-2xl overflow-hidden bg-slate-100">
                {/* Embed iframe for A-21, Basant Vihar Colony, Lashkar, Gwalior */}
                <iframe
                  title="Lahariya Health Clinic Location Map"
                  src="https://maps.google.com/maps?q=Basant%20Vihar%20Colony,%20Lashkar,%20Gwalior,%20Madhya%20Pradesh%20474007&t=&z=15&ie=UTF8&iwloc=&output=embed"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                ></iframe>

                {/* Map Overlay Card */}
                <div className="absolute top-4 left-4 right-4 sm:right-auto sm:max-w-xs bg-white/95 backdrop-blur-md p-3.5 rounded-2xl shadow-lg border border-slate-200">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-600 animate-ping"></div>
                    <span className="text-xs font-black text-slate-900">
                      {lang === 'hi' ? clinicData.name.hi : clinicData.name.en}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 font-medium">
                    A-21, Basant Vihar Colony, Lashkar, Gwalior
                  </p>
                  <a
                    href={googleMapsDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-900"
                  >
                    <span>Open in Google Maps App</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Map Footer Info */}
              <div className="mt-3 px-2 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
                <span>Plus Code: 655F+8QP Gwalior</span>
                <span className="text-emerald-700 font-semibold">Easy parking space available for cars and two-wheelers</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
