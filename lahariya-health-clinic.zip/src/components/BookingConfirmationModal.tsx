import React, { useState } from 'react';
import { CheckCircle2, MessageCircle, Phone, Printer, Copy, Check, X, Calendar, Clock, MapPin, User } from 'lucide-react';
import { Booking, Language } from '../types';
import { clinicData, translations } from '../translations';
import { generateWhatsAppBookingUrl } from '../services/bookingStorage';

interface BookingConfirmationModalProps {
  booking: Booking | null;
  isOpen?: boolean;
  onClose: () => void;
  lang: Language;
}

export const BookingConfirmationModal: React.FC<BookingConfirmationModalProps> = ({
  booking,
  isOpen = true,
  onClose,
  lang,
}) => {
  const [copied, setCopied] = useState(false);
  const t = translations[lang];

  if (!isOpen || !booking) return null;

  const handleCopy = () => {
    const text = `Lahariya Health Clinic Booking
Ref: ${booking.referenceId}
Patient: ${booking.patientName} (${booking.age} yrs)
Phone: ${booking.phoneNumber}
Service: ${booking.serviceType}
Date: ${booking.preferredDate} (${booking.preferredTimeSlot})
Type: ${booking.visitType}
Address: A-21, Basant Vihar Colony, Lashkar, Gwalior
Emergency Contact: 777-300-8103`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  const waUrl = generateWhatsAppBookingUrl(booking);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-900/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Success Badge */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-blue-800 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-full bg-white text-emerald-600 flex items-center justify-center mx-auto mb-3 shadow-lg">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <h3 className="text-2xl font-black text-white">
            {t.confirmation.title}
          </h3>
          <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-md mx-auto">
            {t.confirmation.subtitle}
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Reference ID Banner */}
          <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-center">
            <p className="text-xs uppercase tracking-wider font-bold text-blue-700">
              {t.confirmation.refNumber}
            </p>
            <p className="text-2xl sm:text-3xl font-mono font-black text-blue-900 tracking-wider mt-0.5">
              {booking.referenceId}
            </p>
            <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">
              {t.confirmation.statusPending}
            </span>
          </div>

          {/* Details Table */}
          <div className="rounded-2xl border border-slate-200 divide-y divide-slate-100 text-xs sm:text-sm">
            <div className="p-3 flex justify-between bg-slate-50/50 font-bold text-slate-800">
              <span>{t.confirmation.detailsHeading}</span>
              <span className="text-blue-700">{booking.visitType}</span>
            </div>

            <div className="p-3 flex justify-between">
              <span className="text-slate-500">{t.booking.patientName}</span>
              <span className="font-bold text-slate-900">{booking.patientName} ({booking.age} yrs)</span>
            </div>

            <div className="p-3 flex justify-between">
              <span className="text-slate-500">{t.booking.phoneNumber}</span>
              <span className="font-bold text-slate-900 font-mono">+91 {booking.phoneNumber}</span>
            </div>

            <div className="p-3 flex justify-between">
              <span className="text-slate-500">{t.booking.serviceType}</span>
              <span className="font-bold text-blue-800 text-right">{booking.serviceType}</span>
            </div>

            <div className="p-3 flex justify-between">
              <span className="text-slate-500">{t.booking.preferredDate} & Slot</span>
              <span className="font-bold text-slate-900 text-right">
                {booking.preferredDate} • {booking.preferredTimeSlot}
              </span>
            </div>

            {booking.problemDescription && (
              <div className="p-3 flex justify-between">
                <span className="text-slate-500">{t.booking.problem}</span>
                <span className="font-medium text-slate-800 text-right max-w-xs">{booking.problemDescription}</span>
              </div>
            )}

            <div className="p-3 flex justify-between bg-slate-50/50">
              <span className="text-slate-500">Clinic Address</span>
              <span className="font-medium text-slate-800 text-right">A-21, Basant Vihar Colony, Lashkar, Gwalior</span>
            </div>
          </div>

          {/* WhatsApp Explainer Alert */}
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 leading-relaxed">
            <p className="font-semibold">{t.confirmation.whatsAppNotice}</p>
          </div>

          {/* Action CTAs */}
          <div className="space-y-2.5 pt-2">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm shadow-md transition-all"
            >
              <MessageCircle className="w-5 h-5 fill-current" />
              <span>{t.confirmation.openWhatsApp}</span>
            </a>

            <div className="grid grid-cols-2 gap-2">
              <a
                href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 font-bold text-xs transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>Call Emergency</span>
              </a>

              <button
                onClick={handleCopy}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            >
              {t.confirmation.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
