import React from 'react';
import { Shield, Building2, CreditCard, Phone, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface AyushmanCashlessSectionProps {
  lang: Language;
}

export const AyushmanCashlessSection: React.FC<AyushmanCashlessSectionProps> = ({
  lang,
}) => {
  const t = translations[lang];

  return (
    <section id="ayushman" className="py-16 sm:py-20 bg-slate-50 border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/70 text-blue-800 font-bold text-xs uppercase tracking-wider border border-blue-200 mb-3">
            <Shield className="w-3.5 h-3.5 text-blue-700" />
            {t.ayushman.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {t.ayushman.title}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            {t.ayushman.subtitle}
          </p>
        </div>

        {/* 3 Benefit Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center mb-4">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              {t.ayushman.cards[0].title}
            </h3>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed">
              {t.ayushman.cards[0].desc}
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs font-semibold text-orange-800">
              <CheckCircle2 className="w-4 h-4 text-orange-600 shrink-0" />
              <span>{t.ayushman.cards[0].bullet}</span>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-4">
              <CreditCard className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              {t.ayushman.cards[1].title}
            </h3>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed">
              {t.ayushman.cards[1].desc}
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs font-semibold text-blue-800">
              <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
              <span>{t.ayushman.cards[1].bullet}</span>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4">
              <Building2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              {t.ayushman.cards[2].title}
            </h3>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed">
              {t.ayushman.cards[2].desc}
            </p>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs font-semibold text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{t.ayushman.cards[2].bullet}</span>
            </div>
          </div>
        </div>

        {/* Emergency Admission Helpline */}
        <div className="mt-10 p-5 rounded-2xl bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center shrink-0">
              <Phone className="w-5 h-5 text-rose-300" />
            </div>
            <div>
              <p className="font-extrabold text-sm sm:text-base">
                {t.ayushman.helpline}
              </p>
              <p className="text-xs text-blue-200">
                {lang === 'hi'
                  ? 'अस्पताल में आपातकालीन भर्ती सहायता हेतु 24 घंटे संपर्क सूत्र'
                  : 'Fast-track emergency admission coordination desk'}
              </p>
            </div>
          </div>

          <a
            href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
            className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-extrabold text-sm shadow-md transition-all shrink-0"
          >
            {clinicData.contact.phoneEmergency}
          </a>
        </div>
      </div>
    </section>
  );
};
