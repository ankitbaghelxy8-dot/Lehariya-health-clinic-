import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Phone, Stethoscope, FileText, CheckCircle2, AlertCircle, ArrowRight, Home, Video, Building } from 'lucide-react';
import { Booking, Language, VisitType } from '../types';
import { clinicData, translations } from '../translations';
import { saveNewBooking, generateWhatsAppBookingUrl } from '../services/bookingStorage';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  initialService?: string;
  initialVisitType?: VisitType;
  onBookingSuccess: (booking: Booking) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  lang,
  initialService,
  initialVisitType = 'Clinic',
  onBookingSuccess,
}) => {
  const t = translations[lang];

  // Today's date in YYYY-MM-DD for min date
  const todayStr = new Date().toISOString().split('T')[0];

  const [patientName, setPatientName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [age, setAge] = useState<string>('');
  const [serviceType, setServiceType] = useState(
    initialService || t.booking.serviceOptions[0]
  );
  const [preferredDate, setPreferredDate] = useState(todayStr);
  const [preferredTimeSlot, setPreferredTimeSlot] = useState(t.booking.timeSlots[0]);
  const [visitType, setVisitType] = useState<VisitType>(initialVisitType);
  const [problemDescription, setProblemDescription] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialService) {
      setServiceType(initialService);
    }
  }, [initialService]);

  useEffect(() => {
    if (initialVisitType) {
      setVisitType(initialVisitType);
    }
  }, [initialVisitType]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!patientName.trim()) {
      errs.patientName = t.booking.validation.nameRequired;
    }

    const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
    if (cleanPhone.length !== 10) {
      errs.phoneNumber = t.booking.validation.phoneInvalid;
    }

    const ageNum = parseInt(age, 10);
    if (!age || isNaN(ageNum) || ageNum < 1 || ageNum > 120) {
      errs.age = t.booking.validation.ageInvalid;
    }

    if (!preferredDate) {
      errs.preferredDate = t.booking.validation.dateRequired;
    } else if (preferredDate < todayStr) {
      errs.preferredDate = t.booking.validation.datePast;
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    try {
      const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
      const newBooking = await saveNewBooking({
        patientName: patientName.trim(),
        phoneNumber: cleanPhone,
        age: parseInt(age, 10),
        serviceType,
        preferredDate,
        preferredTimeSlot,
        visitType,
        problemDescription: problemDescription.trim() || undefined,
      });

      // Generate pre-filled WhatsApp link and open it
      const waUrl = generateWhatsAppBookingUrl(newBooking);
      window.open(waUrl, '_blank', 'noopener,noreferrer');

      // Trigger success confirmation screen
      onBookingSuccess(newBooking);
      onClose();
    } catch (err) {
      console.error('Failed to submit appointment:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-800 via-blue-700 to-indigo-900 text-white p-5 sm:p-6 shrink-0 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-200 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>{lang === 'hi' ? 'लहरिया हेल्थ क्लीनिक ग्वालियर' : 'Lahariya Health Clinic, Gwalior'}</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-white">
            {t.booking.modalTitle}
          </h3>
          <p className="text-xs sm:text-sm text-blue-100 mt-1">
            {t.booking.subtitle}
          </p>
        </div>

        {/* Modal Body: Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {/* Visit Type Selector (Buttons) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              {t.booking.visitType} <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setVisitType('Clinic')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  visitType === 'Clinic'
                    ? 'bg-blue-50 border-blue-600 text-blue-700 ring-2 ring-blue-600/20'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Building className="w-4 h-4 text-blue-600" />
                <span>{t.booking.visitTypes.clinic}</span>
              </button>

              <button
                type="button"
                onClick={() => setVisitType('Online Video Consult')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  visitType === 'Online Video Consult'
                    ? 'bg-blue-50 border-blue-600 text-blue-700 ring-2 ring-blue-600/20'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Video className="w-4 h-4 text-emerald-600" />
                <span>{t.booking.visitTypes.video}</span>
              </button>

              <button
                type="button"
                onClick={() => setVisitType('Home Visit')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  visitType === 'Home Visit'
                    ? 'bg-blue-50 border-blue-600 text-blue-700 ring-2 ring-blue-600/20'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Home className="w-4 h-4 text-amber-600" />
                <span>{t.booking.visitTypes.home}</span>
              </button>
            </div>
          </div>

          {/* Patient Name & Age Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-8">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.booking.patientName} <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder={t.booking.patientNamePlaceholder}
                  className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-hidden focus:ring-2 ${
                    errors.patientName
                      ? 'border-red-500 ring-red-200'
                      : 'border-slate-200 focus:border-blue-600 focus:ring-blue-100'
                  }`}
                />
              </div>
              {errors.patientName && (
                <p className="text-xs text-red-600 font-semibold mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {errors.patientName}
                </p>
              )}
            </div>

            <div className="sm:col-span-4">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.booking.age} <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                max="120"
                required
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder={t.booking.agePlaceholder}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-medium focus:outline-hidden focus:ring-2 ${
                  errors.age
                    ? 'border-red-500 ring-red-200'
                    : 'border-slate-200 focus:border-blue-600 focus:ring-blue-100'
                }`}
              />
              {errors.age && (
                <p className="text-xs text-red-600 font-semibold mt-1">
                  {errors.age}
                </p>
              )}
            </div>
          </div>

          {/* Phone Number with 10-digit validation */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.booking.phoneNumber} <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute left-3.5 top-3 flex items-center gap-1 text-xs font-bold text-slate-500 border-r border-slate-200 pr-2">
                <span>+91</span>
              </div>
              <input
                type="tel"
                maxLength={10}
                required
                value={phoneNumber}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9]/g, '');
                  setPhoneNumber(val);
                }}
                placeholder={t.booking.phoneNumberPlaceholder}
                className={`w-full pl-16 pr-4 py-2.5 rounded-xl border text-sm font-mono font-medium focus:outline-hidden focus:ring-2 ${
                  errors.phoneNumber
                    ? 'border-red-500 ring-red-200'
                    : 'border-slate-200 focus:border-blue-600 focus:ring-blue-100'
                }`}
              />
            </div>
            {errors.phoneNumber ? (
              <p className="text-xs text-red-600 font-semibold mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.phoneNumber}
              </p>
            ) : (
              <p className="text-[11px] text-slate-500 mt-1">
                {t.booking.phoneNumberHelp}
              </p>
            )}
          </div>

          {/* Service Required Dropdown */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.booking.serviceType} <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Stethoscope className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 pointer-events-none" />
              <select
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value)}
                className="w-full pl-10 pr-8 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-100 bg-white"
              >
                {t.booking.serviceOptions.map((opt, idx) => (
                  <option key={idx} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Preferred Date & Time Slot Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.booking.preferredDate} <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Calendar className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 pointer-events-none" />
                <input
                  type="date"
                  min={todayStr}
                  required
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2.5 rounded-xl border text-sm font-medium focus:outline-hidden focus:ring-2 ${
                    errors.preferredDate
                      ? 'border-red-500 ring-red-200'
                      : 'border-slate-200 focus:border-blue-600 focus:ring-blue-100'
                  }`}
                />
              </div>
              {errors.preferredDate && (
                <p className="text-xs text-red-600 font-semibold mt-1">
                  {errors.preferredDate}
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.booking.preferredTime} <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Clock className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 pointer-events-none" />
                <select
                  value={preferredTimeSlot}
                  onChange={(e) => setPreferredTimeSlot(e.target.value)}
                  className="w-full pl-10 pr-8 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-100 bg-white"
                >
                  {t.booking.timeSlots.map((slot, idx) => (
                    <option key={idx} value={slot}>
                      {slot}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Problem Description (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.booking.problem}
            </label>
            <div className="relative">
              <FileText className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 pointer-events-none" />
              <textarea
                rows={2}
                value={problemDescription}
                onChange={(e) => setProblemDescription(e.target.value)}
                placeholder={t.booking.problemPlaceholder}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
              />
            </div>
          </div>

          {/* Note / WhatsApp trigger explainer */}
          <div className="p-3.5 rounded-xl bg-blue-50/80 border border-blue-200 text-xs text-blue-900 leading-relaxed">
            <p className="font-semibold">{t.booking.note}</p>
          </div>

          {/* Submit button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 hover:from-blue-800 hover:to-indigo-950 text-white font-extrabold text-base shadow-xl shadow-blue-700/25 hover:shadow-2xl transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isSubmitting ? (
                <span>{t.booking.submitting}</span>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>{t.booking.submitBtn}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
