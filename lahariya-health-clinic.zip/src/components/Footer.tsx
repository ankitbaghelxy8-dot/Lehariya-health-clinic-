import React from 'react';
import { MapPin, Phone, MessageCircle, Clock, Shield, Heart, ArrowUp, Lock } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface FooterProps {
  lang: Language;
  onOpenBooking: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  lang,
  onOpenBooking,
  onOpenAdmin,
}) => {
  const t = translations[lang];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const yOffset = -80;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-28 md:pb-16 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
          {/* Clinic Brand & Doctor */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-800 text-white flex items-center justify-center font-black text-2xl shadow-lg relative">
                L
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 rounded-full flex items-center justify-center text-[10px] text-white">
                  +
                </span>
              </div>
              <div>
                <h3 className="text-xl font-black text-white tracking-tight">
                  {lang === 'hi' ? clinicData.name.hi : clinicData.name.en}
                </h3>
                <p className="text-xs text-blue-400 font-semibold">
                  {lang === 'hi' ? clinicData.doctor.nameHi : clinicData.doctor.nameEn} • MD Medicine
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {t.footer.about}
            </p>

            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1 text-xs">
              <p className="font-bold text-white">
                {lang === 'hi' ? 'विशेषज्ञ परामर्श:' : 'Consultant Physician:'}
              </p>
              <p className="text-slate-400">
                {lang === 'hi'
                  ? 'डायबिटीज (शुगर), ब्लड प्रेशर, थायरॉइड, बुखार एवं क्रिटिकल केयर'
                  : 'Diabetes, Blood Pressure, Thyroid, Fevers & Critical Care'}
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-white">
              {t.footer.quickLinks}
            </h4>
            <ul className="space-y-2 text-xs font-medium">
              <li>
                <button
                  onClick={() => scrollTo('hero')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.home}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('services')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.services}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('daycare')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.dayCare}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('homecare')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.homeCare}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('programs')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.specialPrograms}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('ayushman')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.ayushman}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('doctor')}
                  className="hover:text-white transition-colors"
                >
                  {t.nav.aboutDoctor}
                </button>
              </li>
            </ul>
          </div>

          {/* Special Programs & Day Care */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-white">
              {lang === 'hi' ? 'विशेष सेवाएं' : 'Key Facilities'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>• {lang === 'hi' ? 'डे केयर ड्रिप वार्ड (10 AM - 8 PM)' : 'Day Care IV Drip Ward (10 AM - 8 PM)'}</li>
              <li>• {lang === 'hi' ? 'घर पर इंजेक्शन व ड्रिप सुविधा' : 'Home Injections & IV Drips across Gwalior'}</li>
              <li>• {lang === 'hi' ? 'पर्सनलाइज्ड डाइट चार्ट (₹500/माह)' : 'Personalized Diet Chart (₹500/mo)'}</li>
              <li>• {lang === 'hi' ? 'मासिक फाइब्रोस्कैन कैंप (प्रथम गुरुवार)' : 'Monthly Fibroscan Camp (1st Thursday)'}</li>
              <li>• {lang === 'hi' ? 'जन्मदिन पर फ्री चेकअप (रजि. ₹100)' : 'Free Birthday Health Checkup (Reg ₹100)'}</li>
              <li>• {lang === 'hi' ? 'आयुष्मान व कैशलेस भर्ती मार्गदर्शन' : 'Cashless & Ayushman Admission Guidance'}</li>
            </ul>

            <div className="pt-2">
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white font-semibold"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{t.nav.adminPortal}</span>
              </button>
            </div>
          </div>

          {/* Address & Emergency Contacts */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-white">
              {lang === 'hi' ? 'पता व संपर्क सूत्र' : 'Contact & Address'}
            </h4>

            <div className="space-y-2.5 text-xs">
              <p className="flex items-start gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>
                  {lang === 'hi' ? clinicData.contact.addressHi : clinicData.contact.addressEn}
                  <br />
                  <span className="text-blue-400 font-mono font-bold">Plus Code: 655F+8QP</span>
                </span>
              </p>

              <a
                href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
                className="flex items-center gap-2 text-red-400 hover:text-red-300 font-bold"
              >
                <Phone className="w-4 h-4" />
                <span>24x7 Emergency: {clinicData.contact.phoneEmergency}</span>
              </a>

              <a
                href={`tel:${clinicData.contact.phoneLandlineRaw}`}
                className="flex items-center gap-2 text-blue-300 hover:text-white"
              >
                <Phone className="w-4 h-4" />
                <span>Home Care Landline: {clinicData.contact.phoneLandline}</span>
              </a>

              <a
                href={`https://wa.me/${clinicData.contact.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-bold"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>WhatsApp: +91 {clinicData.contact.phoneEmergencyRaw}</span>
              </a>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="w-full py-2.5 rounded-xl bg-blue-700 hover:bg-blue-600 text-white font-bold text-xs shadow-md transition-colors cursor-pointer"
              >
                {t.nav.bookNow}
              </button>
            </div>
          </div>
        </div>

        {/* Disclaimer Bar */}
        <div className="py-6 border-b border-slate-900">
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-400 text-center">
            <p className="text-amber-400/90 font-bold mb-0.5">
              ⚠️ {lang === 'hi' ? 'आपातकालीन सूचना:' : 'Emergency Disclaimer:'}
            </p>
            <p>{t.footer.disclaimer}</p>
          </div>
        </div>

        {/* Bottom row */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>{t.footer.copyright}</p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
