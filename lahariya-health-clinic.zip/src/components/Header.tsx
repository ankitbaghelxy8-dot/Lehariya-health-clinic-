import React, { useState } from 'react';
import { Phone, Clock, Globe, Menu, X, Shield, CalendarCheck, MapPin } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenBooking: () => void;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  onOpenBooking,
  onOpenAdmin,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[lang];

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-xs border-b border-slate-100 transition-all">
      {/* Top micro bar for emergency contact & timings */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4 flex-wrap">
            <a
              href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
              className="flex items-center gap-1.5 font-semibold text-rose-300 hover:text-white transition-colors"
            >
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              <Phone className="w-3.5 h-3.5" />
              <span>
                {lang === 'hi' ? 'आपातकालीन (24x7): ' : 'Emergency (24x7): '}
                <strong className="text-white tracking-wide">{clinicData.contact.phoneEmergency}</strong>
              </span>
            </a>

            <div className="hidden sm:flex items-center gap-1.5 text-blue-200">
              <Phone className="w-3.5 h-3.5" />
              <span>
                {lang === 'hi' ? 'होम केयर लैंडलाइन (9 AM-9 PM): ' : 'Home Care Desk: '}
                <strong className="text-white">{clinicData.contact.phoneLandline}</strong>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-1 text-blue-200">
              <MapPin className="w-3 h-3 text-rose-400" />
              <span>Basant Vihar, Lashkar, Gwalior</span>
            </div>

            {/* Language Toggle */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all border border-white/20 text-xs font-medium cursor-pointer"
              title="Switch Language"
            >
              <Globe className="w-3 h-3 text-cyan-300" />
              <span className="font-bold">{lang === 'en' ? 'हिंदी में पढ़ें' : 'English'}</span>
            </button>

            {/* Staff portal link */}
            <button
              onClick={onOpenAdmin}
              className="text-xs text-blue-200 hover:text-white flex items-center gap-1 py-0.5 px-2 rounded hover:bg-white/10 transition-colors"
            >
              <Shield className="w-3 h-3" />
              <span className="hidden sm:inline">{t.nav.adminPortal}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main navigation container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Clinic Brand / Logo */}
          <div
            onClick={() => scrollTo('hero')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-blue-700 to-blue-900 text-white shadow-md shadow-blue-600/20 group-hover:scale-105 transition-transform">
              {/* Medical emblem */}
              <div className="text-2xl font-black tracking-tighter text-white">L</div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 rounded-full flex items-center justify-center text-white text-[10px] font-bold shadow-xs">
                +
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight leading-none group-hover:text-blue-700 transition-colors">
                  {lang === 'hi' ? clinicData.name.hi : clinicData.name.en}
                </span>
                <span className="hidden xs:inline-block px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-bold uppercase tracking-wider border border-blue-200">
                  Gwalior
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {lang === 'hi' ? clinicData.doctor.nameHi : clinicData.doctor.nameEn} •{' '}
                <span className="text-blue-700 font-semibold">MD (Medicine)</span>
              </p>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center space-x-1 lg:space-x-2 text-sm font-semibold text-slate-700">
            <button
              onClick={() => scrollTo('services')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.services}
            </button>
            <button
              onClick={() => scrollTo('daycare')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.dayCare}
            </button>
            <button
              onClick={() => scrollTo('homecare')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.homeCare}
            </button>
            <button
              onClick={() => scrollTo('programs')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.specialPrograms}
            </button>
            <button
              onClick={() => scrollTo('ayushman')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.ayushman}
            </button>
            <button
              onClick={() => scrollTo('doctor')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.aboutDoctor}
            </button>
            <button
              onClick={() => scrollTo('contact')}
              className="px-3 py-2 rounded-lg hover:text-blue-700 hover:bg-blue-50/70 transition-colors"
            >
              {t.nav.contact}
            </button>
          </nav>

          {/* Right Action buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            <a
              href={`https://wa.me/${clinicData.contact.whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-all shadow-xs"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              WhatsApp
            </a>

            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-blue-700 to-blue-800 hover:from-blue-800 hover:to-blue-900 shadow-md shadow-blue-700/20 hover:shadow-lg transition-all transform active:scale-95 cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4 text-white" />
              <span>{t.nav.bookNow}</span>
            </button>

            {/* Mobile Hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 focus:outline-hidden"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-t border-slate-100 shadow-xl px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-2 duration-200">
          <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-100">
            <button
              onClick={onToggleLang}
              className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-blue-50 text-blue-800 text-xs font-bold"
            >
              <Globe className="w-4 h-4 text-blue-600" />
              <span>{lang === 'en' ? 'हिंदी में बदलें' : 'Switch to English'}</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
            >
              <Shield className="w-4 h-4 text-slate-600" />
              <span>{t.nav.adminPortal}</span>
            </button>
          </div>

          <div className="flex flex-col space-y-1 text-sm font-semibold text-slate-800 pt-1">
            <button
              onClick={() => scrollTo('services')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.services}
            </button>
            <button
              onClick={() => scrollTo('daycare')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.dayCare}
            </button>
            <button
              onClick={() => scrollTo('homecare')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.homeCare}
            </button>
            <button
              onClick={() => scrollTo('programs')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.specialPrograms}
            </button>
            <button
              onClick={() => scrollTo('ayushman')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.ayushman}
            </button>
            <button
              onClick={() => scrollTo('doctor')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.aboutDoctor}
            </button>
            <button
              onClick={() => scrollTo('gallery')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.gallery}
            </button>
            <button
              onClick={() => scrollTo('reviews')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.reviews}
            </button>
            <button
              onClick={() => scrollTo('contact')}
              className="text-left py-2.5 px-3 rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-700"
            >
              {t.nav.contact}
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            <a
              href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-red-600 text-white font-bold text-sm shadow-md"
            >
              <Phone className="w-4 h-4" />
              <span>{lang === 'hi' ? '24x7 इमरजेंसी कॉल: 777-300-8103' : 'Emergency Call: 777-300-8103'}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
