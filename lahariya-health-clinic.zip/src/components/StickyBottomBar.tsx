import React from 'react';
import { Phone, MessageCircle, CalendarCheck } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface StickyBottomBarProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const StickyBottomBar: React.FC<StickyBottomBarProps> = ({
  lang,
  onOpenBooking,
}) => {
  const t = translations[lang];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-8px_20px_rgba(0,0,0,0.08)] px-3 py-2.5">
      <div className="max-w-md mx-auto grid grid-cols-12 gap-2">
        {/* Call Emergency Button */}
        <a
          href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
          className="col-span-3 flex flex-col items-center justify-center p-2 rounded-xl bg-red-50 active:bg-red-100 text-red-700 border border-red-200 transition-colors"
          aria-label="Call Emergency Helpline"
        >
          <Phone className="w-5 h-5 fill-current" />
          <span className="text-[10px] font-black uppercase mt-0.5 tracking-tight">
            {lang === 'hi' ? 'कॉल करें' : 'Call'}
          </span>
        </a>

        {/* WhatsApp Chat Button */}
        <a
          href={`https://wa.me/${clinicData.contact.whatsappNumber}?text=${encodeURIComponent(
            lang === 'hi'
              ? 'नमस्ते डॉ. लहरिया, मुझे अपॉइंटमेंट एवं क्लीनिक सेवाओं की जानकारी चाहिए।'
              : 'Hello Dr. Deepankar Lahariya, I would like to consult with you at Lahariya Health Clinic.'
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="col-span-3 flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 active:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors"
          aria-label="Chat on WhatsApp"
        >
          <MessageCircle className="w-5 h-5 fill-current" />
          <span className="text-[10px] font-black uppercase mt-0.5 tracking-tight">
            WhatsApp
          </span>
        </a>

        {/* Book Appointment CTA */}
        <button
          onClick={onOpenBooking}
          className="col-span-6 flex items-center justify-center gap-1.5 p-2 rounded-xl bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 text-white font-black text-xs shadow-md shadow-blue-700/25 active:scale-95 transition-all cursor-pointer"
        >
          <CalendarCheck className="w-4 h-4 text-white shrink-0" />
          <span className="truncate">{t.stickyBar.book}</span>
        </button>
      </div>
    </div>
  );
};
