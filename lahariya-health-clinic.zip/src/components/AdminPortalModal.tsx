import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  Search,
  Filter,
  CheckCircle,
  Clock,
  Phone,
  MessageCircle,
  Download,
  Plus,
  Trash2,
  Calendar,
  User,
  ShieldCheck,
  RefreshCw,
  Eye,
  EyeOff,
} from 'lucide-react';
import { Booking, BookingStatus, Language, VisitType } from '../types';
import { translations } from '../translations';
import {
  fetchAllBookings,
  updateBookingStatus,
  deleteBooking,
  saveNewBooking,
  generatePatientConfirmationWhatsAppUrl,
  exportBookingsToCSV,
} from '../services/bookingStorage';

interface AdminPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

const DEFAULT_ADMIN_PASSWORD = 'lahariya777';

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const t = translations[lang];

  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('lahariya_admin_logged_in') === 'true';
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');

  // Data state
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [dateFilter, setDateFilter] = useState<string>('All'); // 'All' | 'Today' | 'Tomorrow' | 'custom'
  const [customDate, setCustomDate] = useState('');
  const [visitTypeFilter, setVisitTypeFilter] = useState<string>('All');

  // Add walk-in state
  const [showAddModal, setShowAddModal] = useState(false);
  const [walkinName, setWalkinName] = useState('');
  const [walkinPhone, setWalkinPhone] = useState('');
  const [walkinAge, setWalkinAge] = useState('40');
  const [walkinService, setWalkinService] = useState(t.booking.serviceOptions[0]);
  const [walkinType, setWalkinType] = useState<VisitType>('Clinic');
  const [walkinDate, setWalkinDate] = useState(new Date().toISOString().split('T')[0]);
  const [walkinSlot, setWalkinSlot] = useState(t.booking.timeSlots[0]);

  const loadData = async () => {
    setLoading(true);
    const data = await fetchAllBookings();
    setBookings(data);
    setLoading(false);
  };

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      loadData();
    }
  }, [isOpen, isAuthenticated]);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === DEFAULT_ADMIN_PASSWORD || passwordInput === 'admin123') {
      setIsAuthenticated(true);
      sessionStorage.setItem('lahariya_admin_logged_in', 'true');
      setAuthError('');
      loadData();
    } else {
      setAuthError(t.admin.invalidPassword);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('lahariya_admin_logged_in');
    setPasswordInput('');
  };

  const handleStatusChange = async (id: string, newStatus: BookingStatus) => {
    const updated = await updateBookingStatus(id, newStatus);
    if (updated) {
      setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status: newStatus } : b)));
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this booking record?')) {
      await deleteBooking(id);
      setBookings((prev) => prev.filter((b) => b.id !== id));
    }
  };

  const handleAddWalkin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!walkinName.trim() || !walkinPhone.trim()) return;

    const newB = await saveNewBooking({
      patientName: walkinName.trim(),
      phoneNumber: walkinPhone.replace(/[^0-9]/g, ''),
      age: parseInt(walkinAge, 10) || 35,
      serviceType: walkinService,
      preferredDate: walkinDate,
      preferredTimeSlot: walkinSlot,
      visitType: walkinType,
      problemDescription: 'Walk-in / Clinic desk registration',
    });

    setBookings((prev) => [newB, ...prev]);
    setShowAddModal(false);
    setWalkinName('');
    setWalkinPhone('');
  };

  // Filter calculations
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const filteredBookings = bookings.filter((b) => {
    // Search
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchName = b.patientName.toLowerCase().includes(q);
      const matchPhone = b.phoneNumber.includes(q);
      const matchRef = b.referenceId.toLowerCase().includes(q);
      const matchService = b.serviceType.toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchRef && !matchService) return false;
    }

    // Status
    if (statusFilter !== 'All' && b.status !== statusFilter) {
      return false;
    }

    // Visit type
    if (visitTypeFilter !== 'All' && b.visitType !== visitTypeFilter) {
      return false;
    }

    // Date
    if (dateFilter === 'Today') {
      return b.preferredDate === todayStr;
    }
    if (dateFilter === 'Tomorrow') {
      return b.preferredDate === tomorrowStr;
    }
    if (dateFilter === 'custom' && customDate) {
      return b.preferredDate === customDate;
    }

    return true;
  });

  // Stats
  const totalCount = bookings.length;
  const todayCount = bookings.filter((b) => b.preferredDate === todayStr).length;
  const pendingCount = bookings.filter((b) => b.status === 'Pending').length;
  const homeCount = bookings.filter((b) => b.visitType === 'Home Visit').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-6xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[94vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white p-5 sm:p-6 shrink-0 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                {t.admin.title}
              </h3>
              <p className="text-xs text-slate-300">
                {t.admin.subtitle} • Basant Vihar, Gwalior
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold text-slate-200 transition-colors"
              >
                {t.admin.logoutBtn}
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        {!isAuthenticated ? (
          /* Login Screen */
          <div className="p-8 sm:p-12 max-w-md mx-auto w-full text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h4 className="text-xl font-black text-slate-900">
                Clinic Staff Authentication
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Enter your authorized passcode to view and manage appointments.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder={t.admin.passwordPlaceholder}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm font-mono font-medium focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-100 pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {authError && (
                <p className="text-xs text-red-600 font-bold">{authError}</p>
              )}

              <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-800 font-medium">
                💡 <strong>Hint:</strong> {t.admin.passwordHelp}
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                {t.admin.loginBtn}
              </button>
            </form>
          </div>
        ) : (
          /* Main Dashboard */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700">
                  {t.admin.statsTotal}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-blue-950 mt-0.5">
                  {totalCount}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  {t.admin.statsToday}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-emerald-950 mt-0.5">
                  {todayCount}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700">
                  {t.admin.statsPending}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-amber-950 mt-0.5">
                  {pendingCount}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700">
                  {t.admin.statsHome}
                </span>
                <p className="text-2xl sm:text-3xl font-black text-indigo-950 mt-0.5">
                  {homeCount}
                </p>
              </div>
            </div>

            {/* Filter and Action Bar */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                {/* Search */}
                <div className="relative flex-1">
                  <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder={t.admin.searchPlaceholder}
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm font-medium focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                {/* Buttons: Add Walk-in & Export */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t.admin.addBookingBtn}</span>
                  </button>

                  <button
                    onClick={() => exportBookingsToCSV(filteredBookings)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-bold text-xs transition-colors cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{t.admin.exportCsv}</span>
                  </button>

                  <button
                    onClick={loadData}
                    className="p-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors"
                    title="Refresh data"
                  >
                    <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Secondary Filter Chips */}
              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200/80 text-xs">
                {/* Status Chips */}
                <span className="font-bold text-slate-500">Status:</span>
                {['All', 'Pending', 'Confirmed', 'Completed', 'Cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                      statusFilter === st
                        ? 'bg-blue-700 text-white shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {st}
                  </button>
                ))}

                <span className="font-bold text-slate-500 ml-2">Date:</span>
                {['All', 'Today', 'Tomorrow'].map((dt) => (
                  <button
                    key={dt}
                    onClick={() => setDateFilter(dt)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                      dateFilter === dt
                        ? 'bg-slate-800 text-white'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {dt}
                  </button>
                ))}

                <div className="flex items-center gap-1 ml-auto">
                  <input
                    type="date"
                    value={customDate}
                    onChange={(e) => {
                      setCustomDate(e.target.value);
                      setDateFilter('custom');
                    }}
                    className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-xs text-slate-700"
                    title="Filter custom date"
                  />
                  {dateFilter === 'custom' && (
                    <button
                      onClick={() => {
                        setDateFilter('All');
                        setCustomDate('');
                      }}
                      className="text-xs text-red-600 font-bold underline"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Bookings Table / Cards */}
            {filteredBookings.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200">
                <p className="text-sm font-bold text-slate-600">{t.admin.emptyState}</p>
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setStatusFilter('All');
                    setDateFilter('All');
                    setCustomDate('');
                  }}
                  className="mt-2 text-xs font-bold text-blue-700 hover:underline"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredBookings.map((b) => {
                  const patientWaConfirmUrl = generatePatientConfirmationWhatsAppUrl(b);

                  return (
                    <div
                      key={b.id}
                      className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-sm hover:border-blue-300 transition-all space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-xs sm:text-sm font-black text-blue-900 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                            {b.referenceId}
                          </span>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                              b.status === 'Confirmed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : b.status === 'Completed'
                                ? 'bg-blue-100 text-blue-800'
                                : b.status === 'Cancelled'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {b.status}
                          </span>
                          <span className="text-xs text-slate-400 font-medium hidden md:inline">
                            Booked: {new Date(b.createdAt).toLocaleDateString()}
                          </span>
                        </div>

                        {/* Status Change Selector */}
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-500">Change Status:</span>
                          <select
                            value={b.status}
                            onChange={(e) => handleStatusChange(b.id, e.target.value as BookingStatus)}
                            className="text-xs font-bold px-2 py-1 rounded-lg border border-slate-200 bg-white"
                          >
                            <option value="Pending">Pending</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Completed">Completed</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>

                      {/* Content Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs sm:text-sm">
                        {/* Patient info */}
                        <div className="md:col-span-4 space-y-1">
                          <p className="font-black text-slate-900 text-base">
                            {b.patientName}{' '}
                            <span className="text-xs font-medium text-slate-500">
                              ({b.age} yrs)
                            </span>
                          </p>
                          <p className="font-mono font-semibold text-slate-700 flex items-center gap-1.5">
                            <Phone className="w-3.5 h-3.5 text-blue-600" />
                            <span>+91 {b.phoneNumber}</span>
                          </p>
                        </div>

                        {/* Service & Visit Type */}
                        <div className="md:col-span-4 space-y-1">
                          <span className="inline-block px-2 py-0.5 rounded-md text-[11px] font-bold bg-slate-100 text-slate-800">
                            {b.visitType}
                          </span>
                          <p className="font-bold text-blue-900">{b.serviceType}</p>
                          {b.problemDescription && (
                            <p className="text-xs text-slate-600 italic line-clamp-2">
                              "{b.problemDescription}"
                            </p>
                          )}
                        </div>

                        {/* Date & Time */}
                        <div className="md:col-span-4 space-y-1">
                          <p className="font-bold text-slate-900 flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-slate-500" />
                            <span>{b.preferredDate}</span>
                          </p>
                          <p className="text-xs text-slate-600 flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-slate-500" />
                            <span>{b.preferredTimeSlot}</span>
                          </p>
                        </div>
                      </div>

                      {/* Action buttons row */}
                      <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2">
                          <a
                            href={`tel:${b.phoneNumber}`}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold"
                          >
                            <Phone className="w-3.5 h-3.5 text-blue-600" />
                            <span>Call</span>
                          </a>

                          <a
                            href={patientWaConfirmUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold border border-emerald-200"
                            title="Send confirmation WhatsApp to patient"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-emerald-600 fill-current" />
                            <span>WhatsApp Confirmation</span>
                          </a>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleStatusChange(b.id, 'Confirmed')}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                          >
                            Confirm
                          </button>
                          <button
                            onClick={() => handleStatusChange(b.id, 'Completed')}
                            className="px-2.5 py-1 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-bold"
                          >
                            Complete
                          </button>
                          <button
                            onClick={() => handleDelete(b.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                            title="Delete booking"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Add Walk-in Modal */}
        {showAddModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h4 className="font-bold text-base text-slate-900">
                  Add Walk-in / Reception Patient
                </h4>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddWalkin} className="space-y-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Patient Name</label>
                  <input
                    type="text"
                    required
                    value={walkinName}
                    onChange={(e) => setWalkinName(e.target.value)}
                    placeholder="e.g. Anand Sharma"
                    className="w-full p-2.5 rounded-lg border border-slate-200 text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Phone Number</label>
                    <input
                      type="tel"
                      required
                      value={walkinPhone}
                      onChange={(e) => setWalkinPhone(e.target.value)}
                      placeholder="98XXXXXXXX"
                      className="w-full p-2.5 rounded-lg border border-slate-200 text-sm"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Age</label>
                    <input
                      type="number"
                      required
                      value={walkinAge}
                      onChange={(e) => setWalkinAge(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Service</label>
                  <select
                    value={walkinService}
                    onChange={(e) => setWalkinService(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 text-sm"
                  >
                    {t.booking.serviceOptions.map((s, idx) => (
                      <option key={idx} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Date</label>
                    <input
                      type="date"
                      value={walkinDate}
                      onChange={(e) => setWalkinDate(e.target.value)}
                      className="w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Slot</label>
                    <select
                      value={walkinSlot}
                      onChange={(e) => setWalkinSlot(e.target.value)}
                      className="w-full p-2 rounded-lg border border-slate-200"
                    >
                      {t.booking.timeSlots.map((ts, idx) => (
                        <option key={idx} value={ts}>{ts}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-blue-700 text-white font-bold text-sm"
                  >
                    Register Walk-in
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
