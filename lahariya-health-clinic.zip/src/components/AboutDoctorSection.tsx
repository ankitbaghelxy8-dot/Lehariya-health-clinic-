import React from 'react';
import { Award, CheckCircle, Heart, ShieldCheck, GraduationCap, Stethoscope, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface AboutDoctorSectionProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const AboutDoctorSection: React.FC<AboutDoctorSectionProps> = ({
  lang,
  onOpenBooking,
}) => {
  const t = translations[lang];

  return (
    <section id="doctor" className="py-16 sm:py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Doctor Portrait / Visual Block */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md">
              <div className="absolute -inset-2 rounded-3xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-red-600 opacity-20 blur-xl"></div>
              
              <div className="relative rounded-3xl bg-gradient-to-b from-blue-900 via-blue-950 to-slate-900 text-white p-7 shadow-2xl border border-blue-800/40 overflow-hidden">
                <div className="flex flex-col items-center text-center">
                  <div className="relative w-36 h-36 rounded-2xl bg-white/10 backdrop-blur-md border-2 border-white/20 flex items-center justify-center shadow-2xl mb-4">
                    <span className="text-6xl">👨‍⚕️</span>
                    <div className="absolute -bottom-2 -right-2 px-2.5 py-1 rounded-full bg-emerald-500 text-white text-[11px] font-bold shadow-md flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Verified MD</span>
                    </div>
                  </div>

                  <h3 className="text-2xl font-black text-white">
                    {lang === 'hi' ? clinicData.doctor.nameHi : clinicData.doctor.nameEn}
                  </h3>
                  <p className="text-sm font-bold text-blue-300 mt-1">
                    {clinicData.doctor.degrees}
                  </p>
                  <p className="text-xs text-slate-300 mt-1">
                    {lang === 'hi' ? clinicData.doctor.designationHi : clinicData.doctor.designationEn}
                  </p>

                  <div className="mt-6 w-full grid grid-cols-2 gap-3 text-left">
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                      <p className="text-[10px] text-blue-300 uppercase font-bold">Experience</p>
                      <p className="text-lg font-black text-white">8+ Years</p>
                    </div>
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                      <p className="text-[10px] text-blue-300 uppercase font-bold">Location</p>
                      <p className="text-sm font-bold text-white">Basant Vihar</p>
                    </div>
                  </div>

                  <div className="mt-4 p-3 rounded-xl bg-blue-800/40 border border-blue-700/50 w-full text-xs text-blue-200 text-center">
                    <p className="font-semibold">
                      {lang === 'hi'
                        ? 'विशेषज्ञ: डायबिटीज, बीपी, थायरॉइड एवं क्रिटिकल केयर'
                        : 'Specialty: Diabetes, BP, Thyroid & Critical Care'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Info */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 font-bold text-xs uppercase tracking-wider border border-blue-200">
              <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
              <span>{t.aboutDoctor.badge}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
              {t.aboutDoctor.title}
            </h2>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <p className="text-sm font-extrabold text-blue-900">
                {t.aboutDoctor.qualifications}
              </p>
            </div>

            <div className="space-y-4 text-base text-slate-600 leading-relaxed font-normal">
              <p>{t.aboutDoctor.bio1}</p>
              <p>{t.aboutDoctor.bio2}</p>
            </div>

            {/* Highlights List */}
            <div className="space-y-2.5 pt-2">
              {t.aboutDoctor.highlights.map((h, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-sm font-semibold text-slate-800">{h}</span>
                </div>
              ))}
            </div>

            <div className="pt-4 flex flex-wrap gap-3">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
              >
                {lang === 'hi' ? 'डॉक्टर से परामर्श बुक करें' : 'Book Consultation with Dr. Lahariya'}
              </button>

              <a
                href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
                className="px-5 py-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm transition-all"
              >
                {lang === 'hi' ? 'सीधा संपर्क: 777-300-8103' : 'Direct Call: 777-300-8103'}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
