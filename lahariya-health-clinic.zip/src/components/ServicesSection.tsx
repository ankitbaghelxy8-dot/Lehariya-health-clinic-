import React from 'react';
import {
  Stethoscope,
  Activity,
  HeartPulse,
  ShieldAlert,
  Thermometer,
  Wind,
  Heart,
  Pill,
  Droplet,
  Brain,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface ServicesSectionProps {
  lang: Language;
  onSelectServiceForBooking: (serviceName: string) => void;
}

const iconMap: Record<string, React.ReactNode> = {
  Stethoscope: <Stethoscope className="w-6 h-6" />,
  Activity: <Activity className="w-6 h-6" />,
  HeartPulse: <HeartPulse className="w-6 h-6" />,
  ShieldAlert: <ShieldAlert className="w-6 h-6" />,
  Thermometer: <Thermometer className="w-6 h-6" />,
  Wind: <Wind className="w-6 h-6" />,
  Heart: <Heart className="w-6 h-6" />,
  Pill: <Pill className="w-6 h-6" />,
  Droplet: <Droplet className="w-6 h-6" />,
  Brain: <Brain className="w-6 h-6" />,
  ShieldCheck: <ShieldCheck className="w-6 h-6" />,
  Sparkles: <Sparkles className="w-6 h-6" />,
};

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  lang,
  onSelectServiceForBooking,
}) => {
  const t = translations[lang];

  return (
    <section id="services" className="py-16 sm:py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 font-bold text-xs uppercase tracking-wider border border-blue-200 mb-3">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
            {t.services.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {t.services.title}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            {t.services.subtitle}
          </p>
        </div>

        {/* Services Grid (12 items) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {t.services.list.map((service) => (
            <div
              key={service.id}
              className={`group relative rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 bg-white border ${
                service.highlight
                  ? 'border-blue-200 shadow-lg shadow-blue-500/5 ring-1 ring-blue-500/10'
                  : 'border-slate-200/80 hover:border-blue-300 hover:shadow-xl'
              }`}
            >
              {service.highlight && (
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-blue-600 text-white">
                    {lang === 'hi' ? 'विशेषज्ञ सेवा' : 'Specialty'}
                  </span>
                </div>
              )}

              {/* Icon Container */}
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 transition-transform group-hover:scale-110 ${
                  service.highlight
                    ? 'bg-blue-700 text-white shadow-md shadow-blue-700/20'
                    : 'bg-slate-100 text-blue-700 group-hover:bg-blue-50'
                }`}
              >
                {iconMap[service.iconName] || <Stethoscope className="w-6 h-6" />}
              </div>

              {/* Title & Description */}
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                {service.title}
              </h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed min-h-[60px]">
                {service.desc}
              </p>

              {/* Tags */}
              <div className="mt-4 flex flex-wrap gap-1.5 pt-3 border-t border-slate-100">
                {service.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded bg-slate-50 text-slate-600 text-xs font-medium border border-slate-200/60"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Action Button */}
              <div className="mt-5 pt-3">
                <button
                  onClick={() => onSelectServiceForBooking(service.title)}
                  className="w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl text-xs font-bold text-blue-700 bg-blue-50/70 hover:bg-blue-700 hover:text-white transition-all cursor-pointer group/btn"
                >
                  <span>{t.services.bookServiceBtn}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
