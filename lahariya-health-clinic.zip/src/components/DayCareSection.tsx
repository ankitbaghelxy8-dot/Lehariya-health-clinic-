import React from 'react';
import { Clock, Syringe, Home, CheckCircle2, Phone, CalendarCheck, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface DayCareSectionProps {
  lang: Language;
  onBookDayCare: (serviceName: string, visitType?: 'Clinic' | 'Home Visit') => void;
}

export const DayCareSection: React.FC<DayCareSectionProps> = ({
  lang,
  onBookDayCare,
}) => {
  const t = translations[lang];

  return (
    <section id="daycare" className="py-16 sm:py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Side: Info & Features */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-bold uppercase tracking-wider">
              <Syringe className="w-3.5 h-3.5 text-blue-400" />
              <span>{t.dayCare.badge}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              {t.dayCare.title}
            </h2>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {t.dayCare.subtitle}
            </p>

            {/* Prominent Timing & Home Availability Banner */}
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-900/80 to-indigo-900/80 border border-blue-700/50 shadow-xl space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shrink-0 text-white font-bold">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm sm:text-base font-bold text-white">
                    {t.dayCare.highlightText}
                  </p>
                  <p className="text-xs text-blue-200">
                    {lang === 'hi' ? 'क्लीनिक पर आरामदायक बेड एवं निरंतर मॉनिटरिंग' : 'Clinic observation beds & continuous vital monitoring'}
                  </p>
                </div>
              </div>

              {/* Home injection callout */}
              <div className="flex items-start gap-3 pt-3 border-t border-blue-800/60">
                <div className="w-8 h-8 rounded-lg bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center shrink-0 text-emerald-400 mt-0.5">
                  <Home className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-semibold text-emerald-300">
                    {t.dayCare.homeFacilityNote}
                  </p>
                </div>
              </div>
            </div>

            {/* Features Checklist */}
            <div className="space-y-2.5 pt-2">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {lang === 'hi' ? 'डे केयर में उपलब्ध सुविधाएं:' : 'Key Day Care Protocols:'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {t.dayCare.features.map((feature, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs sm:text-sm text-slate-200"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-4">
              <button
                onClick={() =>
                  onBookDayCare(
                    lang === 'hi' ? 'डे केयर ड्रिप / इंजेक्शन सुविधा' : 'Day Care IV Drip / Injection Facility',
                    'Clinic'
                  )
                }
                className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4" />
                <span>{t.dayCare.bookDayCare}</span>
              </button>

              <button
                onClick={() =>
                  onBookDayCare(
                    lang === 'hi' ? 'होम विजिट (डॉक्टर / नर्स घर पर)' : 'Home Healthcare Visit (Doctor / Nurse)',
                    'Home Visit'
                  )
                }
                className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-sm shadow-lg transition-all cursor-pointer"
              >
                <Home className="w-4 h-4" />
                <span>{t.dayCare.requestHomeInjection}</span>
              </button>

              <a
                href={`tel:${clinicData.contact.phoneLandlineRaw}`}
                className="flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700"
              >
                <Phone className="w-4 h-4 text-blue-400" />
                <span>{clinicData.contact.phoneLandline}</span>
              </a>
            </div>
          </div>

          {/* Right Side: Day Care Experience Card */}
          <div className="lg:col-span-5">
            <div className="rounded-3xl bg-gradient-to-b from-slate-800 to-slate-850 p-6 sm:p-8 border border-slate-700 shadow-2xl relative">
              <div className="flex items-center justify-between pb-4 border-b border-slate-700">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span className="font-bold text-sm text-white">
                    {lang === 'hi' ? 'डॉक्टर-सुपरवाइज्ड केयर' : 'Doctor-Supervised Setting'}
                  </span>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-900/60 text-blue-300 border border-blue-600/40">
                  Basant Vihar
                </span>
              </div>

              {/* Ward preview details */}
              <div className="mt-6 space-y-4">
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/80 space-y-1">
                  <span className="text-xs font-bold text-blue-400 uppercase">
                    {lang === 'hi' ? 'त्वरित रिकवरी' : 'Rapid Patient Stabilization'}
                  </span>
                  <h4 className="text-base font-bold text-white">
                    {lang === 'hi' ? 'बुखार, डिहाइड्रेशन व अत्यधिक कमजोरी' : 'Fever, Severe Dehydration & Weakness'}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {lang === 'hi'
                      ? 'मरीज़ को 2 से 4 घंटे की आवश्यक आईवी ड्रिप व इंजेक्शन देकर उसी दिन स्वस्थ करके घर भेजा जाता है।'
                      : 'Patients receive targeted 2-4 hours IV therapy and return comfortably home the same day.'}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/80 space-y-1">
                  <span className="text-xs font-bold text-rose-400 uppercase">
                    {lang === 'hi' ? 'घर पर सुविधा' : 'Home Drip Assistance'}
                  </span>
                  <h4 className="text-base font-bold text-white">
                    {lang === 'hi' ? 'बुजुर्ग व असमर्थ मरीज़ों हेतु होम विजिट' : 'Home Visits For Bedridden Patients'}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {lang === 'hi'
                      ? 'लश्कर, बसंत विहार, सिटी सेंटर व संपूर्ण ग्वालियर में स्टाफ घर पहुंचकर सुरक्षित ड्रिप लगाता है।'
                      : 'Our nurse reaches your doorstep across Gwalior with sterile consumables and doctor oversight.'}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300">
                  <p className="font-bold">
                    {lang === 'hi' ? '📞 आपातकालीन संपर्क:' : '📞 Immediate Assistance:'}
                  </p>
                  <p className="mt-1">
                    {lang === 'hi'
                      ? 'डे केयर बेड या होम ड्रिप बुक करने हेतु 777-300-8103 या 0751-3581457 पर सीधे कॉल करें।'
                      : 'Call 777-300-8103 or 0751-3581457 directly for prompt allocation.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
