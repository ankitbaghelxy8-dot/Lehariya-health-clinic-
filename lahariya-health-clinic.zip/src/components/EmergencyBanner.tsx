import React from 'react';
import { AlertCircle, Phone, ArrowRight } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface EmergencyBannerProps {
  lang: Language;
}

export const EmergencyBanner: React.FC<EmergencyBannerProps> = ({ lang }) => {
  const t = translations[lang];

  return (
    <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white shadow-md relative overflow-hidden">
      {/* Subtle pulse accent */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-white/15 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 sm:py-3 relative z-10 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 animate-pulse">
            <AlertCircle className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest font-black text-rose-200">
              {t.emergency.title}
            </p>
            <p className="text-sm sm:text-base font-bold text-white">
              {t.emergency.text}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={`tel:${clinicData.contact.phoneEmergencyRaw}`}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-red-700 font-extrabold text-sm shadow-md hover:bg-rose-50 transition-all hover:scale-105 active:scale-95"
          >
            <Phone className="w-4 h-4 fill-current" />
            <span>{clinicData.contact.phoneEmergency}</span>
          </a>
          <a
            href={`https://wa.me/${clinicData.contact.whatsappNumber}?text=${encodeURIComponent(
              lang === 'hi'
                ? 'नमस्ते डॉ. लहरिया, आपातकालीन सहायता की आवश्यकता है।'
                : 'Hello Dr. Lahariya, urgent medical emergency assistance needed.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-800/80 hover:bg-red-900 text-white font-bold text-xs border border-white/20 transition-all"
          >
            <span>{t.emergency.whatsappBtn}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
