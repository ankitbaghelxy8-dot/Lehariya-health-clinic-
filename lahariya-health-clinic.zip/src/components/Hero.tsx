import React from 'react';
import { Calendar, MessageCircle, Phone, Award, ShieldCheck, HeartPulse, Clock, Sparkles, MapPin } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface HeroProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onOpenBooking }) => {
  const t = translations[lang];

  return (
    <section id="hero" className="relative pt-6 pb-12 sm:pt-10 sm:pb-20 overflow-hidden bg-gradient-to-b from-blue-50/70 via-white to-slate-50">
      {/* Decorative medical background elements */}
      <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-blue-100/60 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 rounded-full bg-red-50/70 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Heading & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Top pill badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-900 text-xs sm:text-sm font-bold shadow-xs">
              <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
              <MapPin className="w-3.5 h-3.5 text-red-600" />
              <span>A-21, Basant Vihar Colony, Lashkar, Gwalior</span>
            </div>

            {/* Main title */}
            <div className="space-y-2">
              <div className="flex items-center justify-center lg:justify-start gap-2 text-xs sm:text-sm font-bold tracking-widest uppercase text-blue-700">
                <span>{lang === 'hi' ? clinicData.name.hi : clinicData.name.en}</span>
                <span>•</span>
                <span className="text-red-600">Gwalior</span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.15]">
                <span className="text-blue-700">
                  {lang === 'hi' ? t.hero.heading1 : 'Aapke Ghar Tak'}
                </span>
                <br />
                <span className="relative inline-block text-slate-900">
                  {lang === 'hi' ? t.hero.heading2 : 'Bharosemand Healthcare'}
                  <svg
                    className="absolute -bottom-2 left-0 w-full text-red-600/30"
                    viewBox="0 0 250 8"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M2 6C60 2 190 2 248 6"
                      stroke="currentColor"
                      strokeWidth="4"
                      strokeLinecap="round"
                    />
                  </svg>
                </span>
              </h1>
            </div>

            {/* Doctor Credentials Card */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white border border-blue-100 shadow-md shadow-blue-900/5 text-left transition-all hover:border-blue-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3 mb-3">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
                    <span>{lang === 'hi' ? clinicData.doctor.nameHi : clinicData.doctor.nameEn}</span>
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                      8+ Yrs Exp.
                    </span>
                  </h2>
                  <p className="text-sm font-bold text-blue-800 mt-0.5">
                    {clinicData.doctor.degrees}
                  </p>
                </div>
                <div className="text-left sm:text-right">
                  <span className="inline-block px-2.5 py-1 rounded-lg bg-blue-50 text-blue-900 text-xs font-semibold">
                    {lang === 'hi' ? clinicData.doctor.designationHi : clinicData.doctor.designationEn}
                  </span>
                </div>
              </div>

              {/* Specialty tags */}
              <div className="space-y-1.5">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  {lang === 'hi' ? 'विशेषज्ञता:' : 'Core Specialty:'}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { en: 'Diabetes (CCEBDM)', hi: 'डायबिटीज (शुगर) विशेषज्ञ' },
                    { en: 'Blood Pressure / Hypertension', hi: 'ब्लड प्रेशर विशेषज्ञ' },
                    { en: 'Thyroid Disorders', hi: 'थायरॉइड रोग' },
                    { en: 'Critical Care & Infections', hi: 'क्रिटिकल केयर एवं जटिल बुखार' },
                    { en: 'Cardiology (PGP Cardio)', hi: 'कार्डियोलॉजी असेसमेंट' },
                  ].map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-800 text-xs font-semibold border border-slate-200"
                    >
                      {lang === 'hi' ? s.hi : s.en}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Subheading text */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed font-normal">
              {t.hero.subheading}
            </p>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                onClick={onOpenBooking}
                className="flex items-center justify-center gap-2.5 px-7 py-4 rounded-2xl bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 text-white font-extrabold text-base shadow-xl shadow-blue-700/25 hover:shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Calendar className="w-5 h-5" />
                <span>{t.hero.bookAppointment}</span>
              </button>

              <a
                href={`https://wa.me/${clinicData.contact.whatsappNumber}?text=${encodeURIComponent(
                  lang === 'hi'
                    ? 'नमस्ते डॉ. लहरिया, मुझे क्लीनिक / होम केयर परामर्श हेतु जानकारी चाहिए।'
                    : 'Hello Dr. Lahariya, I would like to book a consultation at Lahariya Health Clinic.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-6 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base shadow-lg shadow-emerald-600/20 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>{t.hero.whatsappUs}</span>
              </a>

              <a
                href={`tel:${clinicData.contact.phoneLandlineRaw}`}
                className="flex items-center justify-center gap-2 px-4 py-4 rounded-2xl bg-white border border-slate-200 text-slate-700 font-bold text-xs sm:text-sm hover:bg-slate-50 transition-all"
                title="Home Care Landline"
              >
                <Phone className="w-4 h-4 text-blue-700" />
                <span>{t.hero.callLandline}</span>
              </a>
            </div>

            {/* Key trust badges / stats */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 border-t border-slate-200/80">
              <div className="p-2.5 rounded-xl bg-white/70 border border-slate-100 text-center">
                <p className="text-xl sm:text-2xl font-black text-blue-700">8+ Yrs</p>
                <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{t.hero.statExperience}</p>
              </div>
              <div className="p-2.5 rounded-xl bg-white/70 border border-slate-100 text-center">
                <p className="text-xl sm:text-2xl font-black text-slate-900">15K+</p>
                <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{t.hero.statPatients}</p>
              </div>
              <div className="p-2.5 rounded-xl bg-white/70 border border-slate-100 text-center">
                <p className="text-xl sm:text-2xl font-black text-red-600">24x7</p>
                <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{t.hero.statEmergency}</p>
              </div>
              <div className="p-2.5 rounded-xl bg-white/70 border border-slate-100 text-center">
                <p className="text-xl sm:text-2xl font-black text-emerald-600">Home Care</p>
                <p className="text-[11px] font-semibold text-slate-500 mt-0.5">{t.hero.statHomeCare}</p>
              </div>
            </div>
          </div>

          {/* Right Column: High visual Doctor / Clinic Showcase Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Decorative gradient glow ring */}
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-red-600 opacity-20 blur-xl"></div>

              <div className="relative bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 overflow-hidden">
                {/* Doctor Avatar / Clinic Banner */}
                <div className="relative h-64 sm:h-72 w-full rounded-2xl overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-950 flex flex-col items-center justify-center text-white p-6 text-center shadow-inner">
                  {/* Background pattern */}
                  <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>

                  {/* Doctor badge image representation */}
                  <div className="relative z-10 w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-white/10 backdrop-blur-md border-4 border-white/30 flex items-center justify-center shadow-xl mb-3">
                    <span className="text-4xl sm:text-5xl">👨‍⚕️</span>
                    <div className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-white">
                      <HeartPulse className="w-4 h-4 animate-pulse" />
                    </div>
                  </div>

                  <div className="relative z-10">
                    <span className="inline-block px-3 py-1 rounded-full bg-red-600/90 text-white text-xs font-black uppercase tracking-wider mb-1">
                      {lang === 'hi' ? 'कंसल्टेंट फिजिशियन' : 'Consultant Physician'}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                      {lang === 'hi' ? clinicData.doctor.nameHi : clinicData.doctor.nameEn}
                    </h3>
                    <p className="text-xs text-blue-200 font-medium mt-1">
                      MBBS, MD (Medicine), PGP Cardiology
                    </p>
                  </div>

                  {/* Quick floating indicator */}
                  <div className="absolute top-3 left-3 bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-full text-[11px] font-bold text-white flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    <span>Clinic Open Today</span>
                  </div>
                </div>

                {/* Key Clinic Features Mini-List */}
                <div className="mt-5 space-y-2.5">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-blue-50/70 border border-blue-100">
                    <div className="w-9 h-9 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div className="text-xs">
                      <p className="font-bold text-slate-900">
                        {lang === 'hi' ? 'डे केयर आईवी ड्रिप वार्ड (10 AM - 8 PM)' : 'Day Care IV Drip Ward (10 AM - 8 PM)'}
                      </p>
                      <p className="text-slate-500">
                        {lang === 'hi' ? 'घर पर भी ड्रिप व इंजेक्शन उपलब्ध' : 'Injections & IV drips at clinic or home'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-50/70 border border-emerald-100">
                    <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="text-xs">
                      <p className="font-bold text-slate-900">
                        {lang === 'hi' ? 'घर पर ब्लड टेस्ट व डिजिटल ईसीजी' : 'Home Blood Sample & Digital ECG'}
                      </p>
                      <p className="text-slate-500">
                        {lang === 'hi' ? 'व्हाट्सएप पर रिपोर्ट एवं डॉक्टर समीक्षा' : 'Direct WhatsApp digital report & review'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 rounded-xl bg-rose-50/70 border border-rose-100">
                    <div className="w-9 h-9 rounded-lg bg-rose-600 text-white flex items-center justify-center shrink-0">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div className="text-xs">
                      <p className="font-bold text-slate-900">
                        {lang === 'hi' ? '24x7 इमरजेंसी रिस्पॉन्स' : '24x7 Emergency Contact'}
                      </p>
                      <p className="text-slate-500">
                        {lang === 'hi' ? 'कॉल करें: 777-300-8103' : 'Call 777-300-8103 for urgent care'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Instant CTA inside card */}
                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <p className="text-[11px] text-slate-400 font-bold uppercase">
                      {lang === 'hi' ? 'परामर्श शुल्क व समय' : 'Consultation Hours'}
                    </p>
                    <p className="text-xs font-bold text-slate-700">10 AM - 2 PM & 5 PM - 8:30 PM</p>
                  </div>
                  <button
                    onClick={onOpenBooking}
                    className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer"
                  >
                    {t.nav.bookNow}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
