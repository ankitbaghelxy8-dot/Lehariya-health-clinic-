import React from 'react';
import { Sparkles, Calendar, Gift, CheckCircle, ArrowRight, Salad, Waves, Stethoscope } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface SpecialProgramsSectionProps {
  lang: Language;
  onSelectProgram: (programName: string) => void;
}

export const SpecialProgramsSection: React.FC<SpecialProgramsSectionProps> = ({
  lang,
  onSelectProgram,
}) => {
  const t = translations[lang];

  return (
    <section id="programs" className="py-16 sm:py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 text-red-700 font-bold text-xs uppercase tracking-wider border border-red-200 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-red-600" />
            {t.specialPrograms.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {t.specialPrograms.title}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            {t.specialPrograms.subtitle}
          </p>
        </div>

        {/* 3 Special Programs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* 1. Diet Chart */}
          <div className="rounded-3xl p-7 bg-gradient-to-b from-amber-50/50 via-white to-white border-2 border-amber-200/80 shadow-lg shadow-amber-500/5 flex flex-col justify-between relative overflow-hidden group hover:border-amber-400 hover:shadow-xl transition-all">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-100 rounded-bl-full opacity-40 pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md">
                  <Salad className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-amber-100 text-amber-900">
                  {t.specialPrograms.programs[0].badge}
                </span>
              </div>

              <h3 className="text-xl font-black text-slate-900">
                {t.specialPrograms.programs[0].title}
              </h3>

              <div className="mt-3 inline-block px-3 py-1 rounded-xl bg-amber-100/70 text-amber-900 text-lg font-black">
                {t.specialPrograms.programs[0].price}
              </div>

              <p className="mt-3 text-xs sm:text-sm text-slate-600 leading-relaxed">
                {t.specialPrograms.programs[0].desc}
              </p>

              <div className="mt-5 space-y-2 border-t border-slate-100 pt-4">
                {t.specialPrograms.programs[0].features.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                    <CheckCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-100">
              <button
                onClick={() => onSelectProgram(t.specialPrograms.programs[0].title)}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-amber-600/20 transition-all cursor-pointer"
              >
                <span>{t.specialPrograms.programs[0].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 2. Fibroscan Camp */}
          <div className="rounded-3xl p-7 bg-gradient-to-b from-blue-50/50 via-white to-white border-2 border-blue-200/80 shadow-lg shadow-blue-500/5 flex flex-col justify-between relative overflow-hidden group hover:border-blue-400 hover:shadow-xl transition-all">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100 rounded-bl-full opacity-40 pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-blue-700 text-white flex items-center justify-center shadow-md">
                  <Waves className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-blue-100 text-blue-900">
                  {t.specialPrograms.programs[1].badge}
                </span>
              </div>

              <h3 className="text-xl font-black text-slate-900">
                {t.specialPrograms.programs[1].title}
              </h3>

              <div className="mt-3 inline-block px-3 py-1 rounded-xl bg-blue-100/70 text-blue-900 text-xs sm:text-sm font-black">
                {t.specialPrograms.programs[1].schedule}
              </div>

              <p className="mt-3 text-xs sm:text-sm text-slate-600 leading-relaxed">
                {t.specialPrograms.programs[1].desc}
              </p>

              <div className="mt-5 space-y-2 border-t border-slate-100 pt-4">
                {t.specialPrograms.programs[1].features.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                    <CheckCircle className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-100">
              <button
                onClick={() => onSelectProgram(t.specialPrograms.programs[1].title)}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-700/20 transition-all cursor-pointer"
              >
                <span>{t.specialPrograms.programs[1].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 3. Birthday Checkup */}
          <div className="rounded-3xl p-7 bg-gradient-to-b from-rose-50/70 via-white to-white border-2 border-red-300 shadow-xl shadow-red-500/10 flex flex-col justify-between relative overflow-hidden group hover:border-red-500 transition-all ring-2 ring-red-500/10">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-100 rounded-bl-full opacity-40 pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-md">
                  <Gift className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-red-100 text-red-900 animate-pulse">
                  {lang === 'hi' ? 'विशेष जनकल्याण' : 'Popular Initiative'}
                </span>
              </div>

              <h3 className="text-xl font-black text-slate-900">
                {t.specialPrograms.programs[2].title}
              </h3>

              <div className="mt-3 inline-block px-3 py-1.5 rounded-xl bg-red-100 text-red-900 text-xs sm:text-sm font-black border border-red-200">
                {t.specialPrograms.programs[2].price}
              </div>

              <p className="mt-3 text-xs sm:text-sm text-slate-600 leading-relaxed">
                {t.specialPrograms.programs[2].desc}
              </p>

              {/* Crucial registration rule */}
              <div className="mt-3 p-2.5 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-800">
                {lang === 'hi'
                  ? '⚠️ नियम: क्लीनिक आने से कम से कम 1 दिन पहले रजिस्ट्रेशन अनिवार्य है।'
                  : '⚠️ Mandatory: Registration at least 1 day prior is strictly required.'}
              </div>

              <div className="mt-4 space-y-2 border-t border-slate-100 pt-3">
                {t.specialPrograms.programs[2].features.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                    <CheckCircle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-100">
              <button
                onClick={() => onSelectProgram(t.specialPrograms.programs[2].title)}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-black text-xs sm:text-sm shadow-lg shadow-red-600/30 transition-all cursor-pointer"
              >
                <span>{t.specialPrograms.programs[2].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
