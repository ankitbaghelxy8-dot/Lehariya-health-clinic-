import React, { useState } from 'react';
import { Camera, Check, Sparkles, Building, Stethoscope, Bed, HeartPulse } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface ClinicGalleryProps {
  lang: Language;
}

export const ClinicGallery: React.FC<ClinicGalleryProps> = ({ lang }) => {
  const t = translations[lang];
  const [selectedTag, setSelectedTag] = useState<string>('All');

  const galleryItems = [
    {
      id: 1,
      titleEn: 'Main Clinic Entrance & Reception',
      titleHi: 'क्लीनिक मुख्य प्रवेश द्वार एवं स्वागत कक्ष',
      tag: 'Reception',
      descEn: 'A-21, Basant Vihar Colony, ground floor accessible reception with sanitized seating.',
      descHi: 'ए-21, बसंत विहार कॉलोनी, भूतल पर सुगम व स्वच्छ रिसेप्शन क्षेत्र।',
      gradient: 'from-blue-600 via-blue-700 to-indigo-800',
      icon: <Building className="w-8 h-8 text-white" />,
    },
    {
      id: 2,
      titleEn: 'Doctor Consultation Chamber',
      titleHi: 'डॉक्टर कंसल्टेशन चैंबर',
      tag: 'Consultation',
      descEn: 'Private, air-conditioned consulting desk with computerized patient records.',
      descHi: 'निजी, शांत एवं वातानुकूलित डॉक्टर जांच कक्ष।',
      gradient: 'from-indigo-600 via-blue-800 to-slate-900',
      icon: <Stethoscope className="w-8 h-8 text-white" />,
    },
    {
      id: 3,
      titleEn: 'Day Care Observation & IV Infusion Ward',
      titleHi: 'डे केयर एवं आईवी ड्रिप वार्ड',
      tag: 'Day Care',
      descEn: 'Comfortable semi-fowler beds with dedicated IV stands for dehydration & antibiotic drips.',
      descHi: 'आरामदायक सेमी-फाउलर बेड व ड्रिप स्टैंड से सुसज्जित डे केयर वार्ड।',
      gradient: 'from-blue-700 via-cyan-800 to-slate-900',
      icon: <Bed className="w-8 h-8 text-white" />,
    },
    {
      id: 4,
      titleEn: '12-Lead Digital ECG & Diagnostic Corner',
      titleHi: '12-लीड डिजिटल ईसीजी एवं डायग्नोस्टिक कॉर्नर',
      tag: 'Diagnostics',
      descEn: 'Calibrated cardiac screening, pulse oximetry, blood sugar & nebulizer setup.',
      descHi: 'हृदय की त्वरित ईसीजी जांच, पल्स ऑक्सीमेट्री एवं नेबुलाइजर व्यवस्था।',
      gradient: 'from-slate-800 via-blue-900 to-indigo-950',
      icon: <HeartPulse className="w-8 h-8 text-white" />,
    },
    {
      id: 5,
      titleEn: 'Sterile Injection & Vaccine Station',
      titleHi: 'स्टरलाइज्ड इंजेक्शन व वैक्सीनेशन स्टेशन',
      tag: 'Procedure',
      descEn: 'Autoclaved sterile disposable equipment adhering to medical safety norms.',
      descHi: 'संक्रमण-मुक्त वातावरण में दर्द रहित इंजेक्शन व टीकाकरण की व्यवस्था।',
      gradient: 'from-indigo-700 via-blue-800 to-slate-800',
      icon: <Sparkles className="w-8 h-8 text-white" />,
    },
    {
      id: 6,
      titleEn: 'Mobile Home Care Kit & Team',
      titleHi: 'मोबाइल होम केयर किट एवं टीम',
      tag: 'Home Care',
      descEn: 'Fully equipped portable medical kit for doorstep blood collection and home ECG in Gwalior.',
      descHi: 'ग्वालियर में घर-घर जाकर सैंपल लेने एवं ईसीजी करने हेतु विशेष मेडिकल किट।',
      gradient: 'from-emerald-700 via-teal-800 to-blue-900',
      icon: <Camera className="w-8 h-8 text-white" />,
    },
  ];

  const tags = ['All', 'Consultation', 'Day Care', 'Diagnostics', 'Reception', 'Home Care'];

  const filteredItems =
    selectedTag === 'All'
      ? galleryItems
      : galleryItems.filter((item) => item.tag === selectedTag);

  return (
    <section id="gallery" className="py-16 sm:py-24 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 font-bold text-xs uppercase tracking-wider border border-blue-200 mb-3">
            <Camera className="w-3.5 h-3.5 text-blue-600" />
            {t.gallery.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {t.gallery.title}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            {t.gallery.subtitle}
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-10">
          {tags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                selectedTag === tag
                  ? 'bg-blue-700 text-white shadow-md shadow-blue-700/20'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Gallery Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all overflow-hidden flex flex-col"
            >
              {/* Photo placeholder / artistic illustration */}
              <div
                className={`h-48 sm:h-52 w-full bg-gradient-to-br ${item.gradient} p-6 flex flex-col justify-between relative text-white`}
              >
                <div className="flex justify-between items-start">
                  <div className="w-12 h-12 rounded-xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center">
                    {item.icon}
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 backdrop-blur-md border border-white/20 text-white">
                    {item.tag}
                  </span>
                </div>

                <div>
                  <span className="text-[11px] text-blue-200 font-bold uppercase tracking-wider">
                    Lahariya Health Clinic • Gwalior
                  </span>
                  <h4 className="text-lg font-bold text-white mt-0.5">
                    {lang === 'hi' ? item.titleHi : item.titleEn}
                  </h4>
                </div>
              </div>

              {/* Description */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {lang === 'hi' ? item.descHi : item.descEn}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-500">
                  <span>Basant Vihar Colony, Lashkar</span>
                  <span className="text-emerald-600 font-bold">10 AM - 8 PM</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
