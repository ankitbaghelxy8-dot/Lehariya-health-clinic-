import React from 'react';
import { Video, TestTube, Package, HeartHandshake, Activity, Phone, ArrowRight, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { clinicData, translations } from '../translations';

interface HomeHealthcareSectionProps {
  lang: Language;
  onBookHomeCare: (serviceName: string) => void;
}

const homeIcons: Record<string, React.ReactNode> = {
  Video: <Video className="w-6 h-6" />,
  TestTube: <TestTube className="w-6 h-6" />,
  Package: <Package className="w-6 h-6" />,
  HeartHandshake: <HeartHandshake className="w-6 h-6" />,
  Activity: <Activity className="w-6 h-6" />,
};

export const HomeHealthcareSection: React.FC<HomeHealthcareSectionProps> = ({
  lang,
  onBookHomeCare,
}) => {
  const t = translations[lang];

  return (
    <section id="homecare" className="py-16 sm:py-24 bg-gradient-to-b from-slate-50 to-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 font-bold text-xs uppercase tracking-wider border border-emerald-200 mb-3">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            {t.homeCare.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {t.homeCare.title}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600">
            {t.homeCare.subtitle}
          </p>

          {/* Landline highlight pill */}
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs sm:text-sm font-bold shadow-xs">
            <Phone className="w-4 h-4 text-blue-700" />
            <span>{t.homeCare.landlineNote}</span>
          </div>
        </div>

        {/* 5 Services Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {t.homeCare.services.map((item) => (
            <div
              key={item.id}
              className="group rounded-2xl p-6 bg-white border border-slate-200/90 hover:border-emerald-500/50 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-5 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                  {homeIcons[item.icon] || <Activity className="w-6 h-6" />}
                </div>

                <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                  {item.title}
                </h3>

                <p className="mt-2.5 text-sm text-slate-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100">
                <button
                  onClick={() => onBookHomeCare(item.title)}
                  className="w-full flex items-center justify-between py-2.5 px-3.5 rounded-xl bg-emerald-50/60 hover:bg-emerald-600 text-emerald-800 hover:text-white text-xs font-bold transition-all cursor-pointer group/btn"
                >
                  <span>{lang === 'hi' ? 'यह सेवा घर पर बुक करें' : 'Book For Home'}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}

          {/* Special Quick Action Card */}
          <div className="rounded-2xl p-6 bg-gradient-to-br from-blue-700 to-indigo-900 text-white flex flex-col justify-between shadow-xl">
            <div>
              <span className="px-2.5 py-1 rounded-md bg-white/20 text-white text-[10px] font-black uppercase tracking-wider">
                {lang === 'hi' ? 'त्वरित सहायता' : 'Direct Helpline'}
              </span>
              <h3 className="text-xl font-black mt-3">
                {lang === 'hi' ? 'बुजुर्ग मरीज़ों हेतु होम विजिट' : 'Home Care Assistance'}
              </h3>
              <p className="mt-2 text-xs sm:text-sm text-blue-100 leading-relaxed">
                {lang === 'hi'
                  ? 'यदि आपके घर में कोई बुजुर्ग या चलने में असमर्थ मरीज़ हैं, तो हमें सीधे कॉल करें। हमारी टीम डॉक्टर व नर्सिंग सहायता उपलब्ध कराएगी।'
                  : 'For bedridden parents or patients unable to travel, call our home healthcare desk directly.'}
              </p>
            </div>

            <div className="mt-6 space-y-2">
              <a
                href={`tel:${clinicData.contact.phoneLandlineRaw}`}
                className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-white text-blue-900 font-extrabold text-xs shadow-md hover:bg-blue-50 transition-all"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Landline: 0751-3581457</span>
              </a>

              <a
                href={`https://wa.me/${clinicData.contact.whatsappNumber}?text=${encodeURIComponent(
                  lang === 'hi'
                    ? 'नमस्ते डॉ. लहरिया, मुझे घर पर होम हेल्थकेयर सेवा चाहिए।'
                    : 'Hello Dr. Lahariya, I need home healthcare service in Gwalior.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all"
              >
                <span>WhatsApp Home Desk</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
